// 게시물 데이터 (자동 생성됨)

// 그리드 탭 (insta-photo)
export const photoPosts = [
    {
        "id": "photo-250930",
        "date": "2025-09-30",
        "displayDate": "2025년 9월 30일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250930%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250930%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250930%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250930%20(4).jpg"
        ],
        "caption": "GET THAT",
        "type": "photo",
        "rawDate": "250930",
        "postNum": null
    },
    {
        "id": "photo-250923",
        "date": "2025-09-23",
        "displayDate": "2025년 9월 23일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250923%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250923%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250923%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250923%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250923%20(5).jpg"
        ],
        "caption": "😶",
        "type": "photo",
        "rawDate": "250923",
        "postNum": null
    },
    {
        "id": "photo-250914",
        "date": "2025-09-14",
        "displayDate": "2025년 9월 14일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250914%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250914%20(2).jpg"
        ],
        "caption": "1-2",
        "type": "photo",
        "rawDate": "250914",
        "postNum": null
    },
    {
        "id": "photo-250823",
        "date": "2025-08-23",
        "displayDate": "2025년 8월 23일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250823%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250823%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250823%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250823%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250823%20(5).jpg"
        ],
        "caption": "📸📸📸📸📸",
        "type": "photo",
        "rawDate": "250823",
        "postNum": null
    },
    {
        "id": "photo-250814",
        "date": "2025-08-14",
        "displayDate": "2025년 8월 14일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250814%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250814%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250814%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250814%20(4).jpg"
        ],
        "caption": "👀",
        "type": "photo",
        "rawDate": "250814",
        "postNum": null
    },
    {
        "id": "photo-250807",
        "date": "2025-08-07",
        "displayDate": "2025년 8월 7일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250807%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250807%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250807%20(3).jpg"
        ],
        "caption": "go on?",
        "type": "photo",
        "rawDate": "250807",
        "postNum": null
    },
    {
        "id": "photo-250716",
        "date": "2025-07-16",
        "displayDate": "2025년 7월 16일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250716%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250716%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250716%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250716%20(4).jpg"
        ],
        "caption": "♾️",
        "type": "photo",
        "rawDate": "250716",
        "postNum": null
    },
    {
        "id": "photo-250704",
        "date": "2025-07-04",
        "displayDate": "2025년 7월 4일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250704%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250704%20(2).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250704%20(3).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250704%20(4).jpeg"
        ],
        "caption": "🎧🎵",
        "type": "photo",
        "rawDate": "250704",
        "postNum": null
    },
    {
        "id": "photo-250610",
        "date": "2025-06-10",
        "displayDate": "2025년 6월 10일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250610.jpg"
        ],
        "caption": "👀",
        "type": "photo",
        "rawDate": "250610",
        "postNum": null
    },
    {
        "id": "photo-250504",
        "date": "2025-05-04",
        "displayDate": "2025년 5월 4일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250504%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250504%20(2).jpg"
        ],
        "caption": "🍃🍃🍃",
        "type": "photo",
        "rawDate": "250504",
        "postNum": null
    },
    {
        "id": "photo-250422",
        "date": "2025-04-22",
        "displayDate": "2025년 4월 22일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250422%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250422%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250422%20(3).jpg"
        ],
        "caption": "⚠️",
        "type": "photo",
        "rawDate": "250422",
        "postNum": null
    },
    {
        "id": "photo-250327",
        "date": "2025-03-27",
        "displayDate": "2025년 3월 27일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250327%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250327%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250327%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250327%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250327%20(5).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250327%20(6).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250327%20(7).jpg"
        ],
        "caption": "🔶🔶🔶",
        "type": "photo",
        "rawDate": "250327",
        "postNum": null
    },
    {
        "id": "photo-250323",
        "date": "2025-03-23",
        "displayDate": "2025년 3월 23일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250323%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250323%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250323%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250323%20(4).jpg"
        ],
        "caption": "날씨 좋음 🤓",
        "type": "photo",
        "rawDate": "250323",
        "postNum": null
    },
    {
        "id": "photo-250318",
        "date": "2025-03-18",
        "displayDate": "2025년 3월 18일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250318%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250318%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250318%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250318%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250318%20(5).jpg"
        ],
        "caption": "✌️✌️",
        "type": "photo",
        "rawDate": "250318",
        "postNum": null
    },
    {
        "id": "photo-250311",
        "date": "2025-03-11",
        "displayDate": "2025년 3월 11일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250311%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250311%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250311%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250311%20(4).jpg"
        ],
        "caption": "👓🎤🎶",
        "type": "photo",
        "rawDate": "250311",
        "postNum": null
    },
    {
        "id": "photo-250219",
        "date": "2025-02-19",
        "displayDate": "2025년 2월 19일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250219%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250219%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250219%20(3).jpg"
        ],
        "caption": "in JAKARTA",
        "type": "photo",
        "rawDate": "250219",
        "postNum": null
    },
    {
        "id": "photo-250210",
        "date": "2025-02-10",
        "displayDate": "2025년 2월 10일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250210%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250210%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250210%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250210%20(4).jpg"
        ],
        "caption": "Doy was in SFW",
        "type": "photo",
        "rawDate": "250210",
        "postNum": null
    },
    {
        "id": "photo-250209",
        "date": "2025-02-09",
        "displayDate": "2025년 2월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250209%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250209%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250209%20(3).jpg"
        ],
        "caption": "잊지 못할 CARNIVAL",
        "type": "photo",
        "rawDate": "250209",
        "postNum": null
    },
    {
        "id": "photo-241226",
        "date": "2024-12-26",
        "displayDate": "2024년 12월 26일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241226%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241226%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241226%20(3).jpg"
        ],
        "caption": "끄적끄적 ",
        "type": "photo",
        "rawDate": "241226",
        "postNum": null
    },
    {
        "id": "photo-241223",
        "date": "2024-12-23",
        "displayDate": "2024년 12월 23일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241223%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241223%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241223%20(3).jpg"
        ],
        "caption": "🎄🎄",
        "type": "photo",
        "rawDate": "241223",
        "postNum": null
    },
    {
        "id": "photo-241216",
        "date": "2024-12-16",
        "displayDate": "2024년 12월 16일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241216%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241216%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241216%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241216%20(4).jpg"
        ],
        "caption": "💤💤💤",
        "type": "photo",
        "rawDate": "241216",
        "postNum": null
    },
    {
        "id": "photo-241205",
        "date": "2024-12-05",
        "displayDate": "2024년 12월 5일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241205%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241205%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241205%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241205%20(4).jpg"
        ],
        "caption": "☀️☀️",
        "type": "photo",
        "rawDate": "241205",
        "postNum": null
    },
    {
        "id": "photo-241127",
        "date": "2024-11-27",
        "displayDate": "2024년 11월 27일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241127%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241127%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241127%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241127%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241127%20(5).jpg"
        ],
        "caption": "❄️❄️❄️",
        "type": "photo",
        "rawDate": "241127",
        "postNum": null
    },
    {
        "id": "photo-241125",
        "date": "2024-11-25",
        "displayDate": "2024년 11월 25일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241125%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241125%20(2).jpg"
        ],
        "caption": "All BLACK",
        "type": "photo",
        "rawDate": "241125",
        "postNum": null
    },
    {
        "id": "photo-241117",
        "date": "2024-11-17",
        "displayDate": "2024년 11월 17일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241117%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241117%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241117%20(3).jpg"
        ],
        "caption": "DOY was here in Jakarta 🇮🇩",
        "type": "photo",
        "rawDate": "241117",
        "postNum": null
    },
    {
        "id": "photo-241112",
        "date": "2024-11-12",
        "displayDate": "2024년 11월 12일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241112%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241112%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241112%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241112%20(4).jpg"
        ],
        "caption": "🍁🍂",
        "type": "photo",
        "rawDate": "241112",
        "postNum": null
    },
    {
        "id": "photo-241109",
        "date": "2024-11-09",
        "displayDate": "2024년 11월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241109%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241109%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241109%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241109%20(4).jpg"
        ],
        "caption": "DO_Y_Vibe",
        "type": "photo",
        "rawDate": "241109",
        "postNum": null
    },
    {
        "id": "photo-241107",
        "date": "2024-11-07",
        "displayDate": "2024년 11월 7일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241107%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241107%20(2).jpg"
        ],
        "caption": "🏊☀️",
        "type": "photo",
        "rawDate": "241107",
        "postNum": null
    },
    {
        "id": "photo-241101",
        "date": "2024-11-01",
        "displayDate": "2024년 11월 1일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241101%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241101%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241101%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241101%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241101%20(5).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241101%20(6).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241101%20(7).jpg"
        ],
        "caption": "KOREA BRAND EXPO📞",
        "type": "photo",
        "rawDate": "241101",
        "postNum": null
    },
    {
        "id": "photo-241028",
        "date": "2024-10-28",
        "displayDate": "2024년 10월 28일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241028%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241028%20(2).jpg"
        ],
        "caption": "Doky",
        "type": "photo",
        "rawDate": "241028",
        "postNum": null
    },
    {
        "id": "photo-241025",
        "date": "2024-10-25",
        "displayDate": "2024년 10월 25일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241025%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241025%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241025%20(3).jpg"
        ],
        "caption": "🐶🐶",
        "type": "photo",
        "rawDate": "241025",
        "postNum": null
    },
    {
        "id": "photo-241012",
        "date": "2024-10-12",
        "displayDate": "2024년 10월 12일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241012%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241012%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241012%20(3).jpg"
        ],
        "caption": "📼🎧🎵",
        "type": "photo",
        "rawDate": "241012",
        "postNum": null
    },
    {
        "id": "photo-240831",
        "date": "2024-08-31",
        "displayDate": "2024년 8월 31일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240831%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240831%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240831%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240831%20(4).jpg"
        ],
        "caption": "Good night🌙",
        "type": "photo",
        "rawDate": "240831",
        "postNum": null
    },
    {
        "id": "photo-240707",
        "date": "2024-07-07",
        "displayDate": "2024년 7월 7일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240707%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240707%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240707%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240707%20(4).jpg"
        ],
        "caption": "주말인데 다들 뭐했어?",
        "type": "photo",
        "rawDate": "240707",
        "postNum": null
    },
    {
        "id": "photo-240621",
        "date": "2024-06-21",
        "displayDate": "2024년 6월 21일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240621%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240621%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240621%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240621%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240621%20(5).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240621%20(6).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240621%20(7).jpg"
        ],
        "caption": "Nos vemos",
        "type": "photo",
        "rawDate": "240621",
        "postNum": null
    },
    {
        "id": "photo-240528",
        "date": "2024-05-28",
        "displayDate": "2024년 5월 28일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240528.jpg"
        ],
        "caption": "☁️ 한 점 없는",
        "type": "photo",
        "rawDate": "240528",
        "postNum": null
    },
    {
        "id": "photo-240522",
        "date": "2024-05-22",
        "displayDate": "2024년 5월 22일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240522%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240522%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240522%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240522%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240522%20(5).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240522%20(6).jpg"
        ],
        "caption": "☀️",
        "type": "photo",
        "rawDate": "240522",
        "postNum": null
    },
    {
        "id": "photo-240514",
        "date": "2024-05-14",
        "displayDate": "2024년 5월 14일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240514%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240514%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240514%20(3).jpg"
        ],
        "caption": "trapped",
        "type": "photo",
        "rawDate": "240514",
        "postNum": null
    },
    {
        "id": "photo-240507",
        "date": "2024-05-07",
        "displayDate": "2024년 5월 7일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240507%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240507%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240507%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240507%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240507%20(5).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240507%20(6).jpg"
        ],
        "caption": "오사카의 밤",
        "type": "photo",
        "rawDate": "240507",
        "postNum": null
    },
    {
        "id": "photo-240504",
        "date": "2024-05-04",
        "displayDate": "2024년 5월 4일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240504%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240504%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240504%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240504%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240504%20(5).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240504%20(6).jpg"
        ],
        "caption": "Osaka street",
        "type": "photo",
        "rawDate": "240504",
        "postNum": null
    },
    {
        "id": "photo-240417",
        "date": "2024-04-17",
        "displayDate": "2024년 4월 17일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240417.jpg"
        ],
        "caption": "Casper",
        "type": "photo",
        "rawDate": "240417",
        "postNum": null
    },
    {
        "id": "photo-240412",
        "date": "2024-04-12",
        "displayDate": "2024년 4월 12일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240412.jpg"
        ],
        "caption": "#DOY_was_here 👣",
        "type": "photo",
        "rawDate": "240412",
        "postNum": null
    },
    {
        "id": "photo-240111-2",
        "date": "2024-01-11",
        "displayDate": "2024년 1월 11일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240111-2.jpg"
        ],
        "caption": "💭",
        "type": "photo",
        "rawDate": "240111",
        "postNum": 2
    },
    {
        "id": "photo-240111",
        "date": "2024-01-11",
        "displayDate": "2024년 1월 11일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240111%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240111%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240111%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240111%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240111%20(5).jpg"
        ],
        "caption": "",
        "type": "photo",
        "rawDate": "240111",
        "postNum": null
    }
];

// 태그 탭 (insta-group)
export const groupPosts = [
    {
        "id": "group-251124-2",
        "date": "2025-11-24",
        "displayDate": "2025년 11월 24일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251124-2%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251124-2%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251124-2%20(3).jpg"
        ],
        "caption": "NOMAD : NO PLAN BEHIND PHOTO",
        "type": "group",
        "rawDate": "251124",
        "postNum": 2
    },
    {
        "id": "group-251124-1",
        "date": "2025-11-24",
        "displayDate": "2025년 11월 24일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251124-1%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251124-1%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251124-1%20(3).jpg"
        ],
        "caption": "NOMAD : NO PLAN BEHIND PHOTO",
        "type": "group",
        "rawDate": "251124",
        "postNum": 1
    },
    {
        "id": "group-251028",
        "date": "2025-10-28",
        "displayDate": "2025년 10월 28일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251028.mp4"
        ],
        "caption": "NOMAD x NUYH NEWYORK @nuyh.newyork",
        "type": "group",
        "rawDate": "251028",
        "postNum": null
    },
    {
        "id": "group-251024",
        "date": "2025-10-24",
        "displayDate": "2025년 10월 24일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251024%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251024%20(2).jpg"
        ],
        "caption": "NUYH NEWYORK 26 S/S Collection 《SHA:DOW | 영影》 | @nuyh.newyork",
        "type": "group",
        "rawDate": "251024",
        "postNum": null
    },
    {
        "id": "group-251017",
        "date": "2025-10-17",
        "displayDate": "2025년 10월 17일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251017.mp4"
        ],
        "caption": "NOMAD x Fashion Hankook @fashion_sportshankook",
        "type": "group",
        "rawDate": "251017",
        "postNum": null
    },
    {
        "id": "group-251010",
        "date": "2025-10-10",
        "displayDate": "2025년 10월 10일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251010%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251010%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251010%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251010%20(4).jpg"
        ],
        "caption": "🔥",
        "type": "group",
        "rawDate": "251010",
        "postNum": null
    },
    {
        "id": "group-251005",
        "date": "2025-10-05",
        "displayDate": "2025년 10월 5일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251005.mp4"
        ],
        "caption": "DOY's first solo stage in C.ATworkFesta @c.atworkfesta @_erer.official",
        "type": "group",
        "rawDate": "251005",
        "postNum": null
    },
    {
        "id": "group-250928",
        "date": "2025-09-28",
        "displayDate": "2025년 9월 28일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250928%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250928%20(2).jpeg"
        ],
        "caption": "2025 C.AT WORK FESTA | ERER @_erer.official",
        "type": "group",
        "rawDate": "250928",
        "postNum": null
    },
    {
        "id": "group-250720",
        "date": "2025-07-20",
        "displayDate": "2025년 7월 20일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250720%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250720%20(2).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250720%20(3).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250720%20(4).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250720%20(5).mp4"
        ],
        "caption": "All India K-POP Contest 2025 🇮🇳 दोबारा जल्दी मिलेंगे ❤️‍🔥",
        "type": "group",
        "rawDate": "250720",
        "postNum": null
    },
    {
        "id": "group-250617",
        "date": "2025-06-17",
        "displayDate": "2025년 6월 17일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250617%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250617%20(2).jpg"
        ],
        "caption": "BOF 🌊",
        "type": "group",
        "rawDate": "250617",
        "postNum": null
    },
    {
        "id": "group-250613",
        "date": "2025-06-13",
        "displayDate": "2025년 6월 13일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250613.jpg"
        ],
        "caption": "2025 BUSAN ONEASIA FESTIVAL BIG CONCERT SHOWCASE",
        "type": "group",
        "rawDate": "250613",
        "postNum": null
    },
    {
        "id": "group-250612",
        "date": "2025-06-12",
        "displayDate": "2025년 6월 12일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250612.jpeg"
        ],
        "caption": "NOMAD X 撕拉片📸",
        "type": "group",
        "rawDate": "250612",
        "postNum": null
    },
    {
        "id": "group-250503",
        "date": "2025-05-03",
        "displayDate": "2025년 5월 3일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250503.jpg"
        ],
        "caption": "NOMAD is here #한강 🎵 25) 05-03",
        "type": "group",
        "rawDate": "250503",
        "postNum": null
    },
    {
        "id": "group-250316",
        "date": "2025-03-16",
        "displayDate": "2025년 3월 16일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250316.jpeg"
        ],
        "caption": "NOMAD LIVE IN TOKYO | 250316",
        "type": "group",
        "rawDate": "250316",
        "postNum": null
    },
    {
        "id": "group-250315",
        "date": "2025-03-15",
        "displayDate": "2025년 3월 15일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250315.jpeg"
        ],
        "caption": "NOMAD LIVE IN TOKYO | 250315",
        "type": "group",
        "rawDate": "250315",
        "postNum": null
    },
    {
        "id": "group-250314",
        "date": "2025-03-14",
        "displayDate": "2025년 3월 14일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250314.jpeg"
        ],
        "caption": "NOMAD LIVE IN TOKYO | 250314",
        "type": "group",
        "rawDate": "250314",
        "postNum": null
    },
    {
        "id": "group-250311",
        "date": "2025-03-11",
        "displayDate": "2025년 3월 11일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250311%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250311%20(2).jpg"
        ],
        "caption": "NOMAD is here in TOKYO TOWER 🗼",
        "type": "group",
        "rawDate": "250311",
        "postNum": null
    },
    {
        "id": "group-250310",
        "date": "2025-03-10",
        "displayDate": "2025년 3월 10일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250310.jpeg"
        ],
        "caption": "NOMAD LIVE IN TOKYO | 250309",
        "type": "group",
        "rawDate": "250310",
        "postNum": null
    },
    {
        "id": "group-250308",
        "date": "2025-03-08",
        "displayDate": "2025년 3월 8일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250308.jpg"
        ],
        "caption": "NOMAD LIVE IN TOKYO | 250308",
        "type": "group",
        "rawDate": "250308",
        "postNum": null
    },
    {
        "id": "group-250228",
        "date": "2025-02-28",
        "displayDate": "2025년 2월 28일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250228.jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250228%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250228%20(2).jpg"
        ],
        "caption": "𝑁𝑂𝑀𝐴𝐷 𝐷𝐸𝐵𝑈𝑇 1𝑠𝑡 𝐴𝑛𝑛𝑖𝑣𝑒𝑟𝑠𝑎𝑟𝑦 🎈",
        "type": "group",
        "rawDate": "250228",
        "postNum": null
    },
    {
        "id": "group-250216",
        "date": "2025-02-16",
        "displayDate": "2025년 2월 16일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250216.jpeg"
        ],
        "caption": "NOMAD Nonsan Strawberry Festival in Jakarta",
        "type": "group",
        "rawDate": "250216",
        "postNum": null
    },
    {
        "id": "group-250209",
        "date": "2025-02-09",
        "displayDate": "2025년 2월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250209%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250209%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250209%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250209%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250209%20(5).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250209%20(6).jpg"
        ],
        "caption": "2025 F/W SeoulFashionWeek : (Corp.) Gravity , @urbansavvy_official",
        "type": "group",
        "rawDate": "250209",
        "postNum": null
    },
    {
        "id": "group-250208-2",
        "date": "2025-02-08",
        "displayDate": "2025년 2월 8일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250208-2.jpg"
        ],
        "caption": "NOMAD 1ST FAN CONCERT <CARNIVAL> <br><br>영원히 노매드만을 위한 카니발을 만들어줄게🤍",
        "type": "group",
        "rawDate": "250208",
        "postNum": 2
    },
    {
        "id": "group-250208-1",
        "date": "2025-02-08",
        "displayDate": "2025년 2월 8일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250208-1%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250208-1%20(2).jpeg"
        ],
        "caption": "NOMAD 1ST FAN CONCERT <CARNIVAL> 🎆",
        "type": "group",
        "rawDate": "250208",
        "postNum": 1
    },
    {
        "id": "group-250207",
        "date": "2025-02-07",
        "displayDate": "2025년 2월 7일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250207%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250207%20(2).jpg"
        ],
        "caption": "2025 F/W SeoulFashionWeek : DAILY MIRROR",
        "type": "group",
        "rawDate": "250207",
        "postNum": null
    },
    {
        "id": "group-250201",
        "date": "2025-02-01",
        "displayDate": "2025년 2월 1일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250201%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250201%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250201%20(3).jpg"
        ],
        "caption": "You are my carnival 🎆",
        "type": "group",
        "rawDate": "250201",
        "postNum": null
    },
    {
        "id": "group-250131",
        "date": "2025-01-31",
        "displayDate": "2025년 1월 31일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250131%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250131%20(2).jpg"
        ],
        "caption": "분(위기) 좋(은) 카니발 🎇",
        "type": "group",
        "rawDate": "250131",
        "postNum": null
    },
    {
        "id": "group-250122",
        "date": "2025-01-22",
        "displayDate": "2025년 1월 22일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250122%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250122%20(2).jpeg"
        ],
        "caption": "NOMAD 1ST FAN CONCERT <CARNIVAL> POSTER<br>#도의 #DOY<br><br>🗓 2025.02.08. SAT 7PM (KST)<br><br>🎆 SHOWKING K-POP CENTER<br>🎫 b.stage+",
        "type": "group",
        "rawDate": "250122",
        "postNum": null
    },
    {
        "id": "group-250109",
        "date": "2025-01-09",
        "displayDate": "2025년 1월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250109%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250109%20(2).jpg"
        ],
        "caption": "Team",
        "type": "group",
        "rawDate": "250109",
        "postNum": null
    },
    {
        "id": "group-241225",
        "date": "2024-12-25",
        "displayDate": "2024년 12월 25일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241225.jpg"
        ],
        "caption": "🎄Merry Christmas🎄",
        "type": "group",
        "rawDate": "241225",
        "postNum": null
    },
    {
        "id": "group-241224",
        "date": "2024-12-24",
        "displayDate": "2024년 12월 24일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241224%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241224%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241224%20(3).jpg"
        ],
        "caption": "NOMAD is here #school 📞  24) 12-24<br><덕성여자고등학교🏫> & <한성여자고등학교🏫>",
        "type": "group",
        "rawDate": "241224",
        "postNum": null
    },
    {
        "id": "group-241223",
        "date": "2024-12-23",
        "displayDate": "2024년 12월 23일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241223%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241223%20(2).jpg"
        ],
        "caption": "🖤 𝐍𝐎𝐌𝐀𝐃 𝐃𝐄𝐁𝐔𝐓 𝟑𝟎𝟎𝐃𝐀𝐘𝐒 🖤",
        "type": "group",
        "rawDate": "241223",
        "postNum": null
    },
    {
        "id": "group-241220",
        "date": "2024-12-20",
        "displayDate": "2024년 12월 20일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241220.jpg"
        ],
        "caption": "NOMAD is here #school 📞 24) 12-20<br><동일여자고등학교🏫>",
        "type": "group",
        "rawDate": "241220",
        "postNum": null
    },
    {
        "id": "group-241214",
        "date": "2024-12-14",
        "displayDate": "2024년 12월 14일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241214.jpg"
        ],
        "caption": "2024 GLOBAL INFLUENCER EXPO 📞 24) 12-14",
        "type": "group",
        "rawDate": "241214",
        "postNum": null
    },
    {
        "id": "group-241213",
        "date": "2024-12-13",
        "displayDate": "2024년 12월 13일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241213.jpeg"
        ],
        "caption": "NOMAD Christmas <MISTLETOE.cover> FILM MOOD 📷",
        "type": "group",
        "rawDate": "241213",
        "postNum": null
    },
    {
        "id": "group-241123",
        "date": "2024-11-23",
        "displayDate": "2024년 11월 23일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241123.jpg"
        ],
        "caption": "Suit MAD 😎",
        "type": "group",
        "rawDate": "241123",
        "postNum": null
    },
    {
        "id": "group-241117",
        "date": "2024-11-17",
        "displayDate": "2024년 11월 17일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241117%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241117%20(2).jpg"
        ],
        "caption": "NOMAD is here 24) 11-16",
        "type": "group",
        "rawDate": "241117",
        "postNum": null
    },
    {
        "id": "group-241109-2",
        "date": "2024-11-09",
        "displayDate": "2024년 11월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241109-2%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241109-2%20(2).jpg"
        ],
        "caption": "NOMAD is here #Hongdae 📞 24) 11-09",
        "type": "group",
        "rawDate": "241109",
        "postNum": 2
    },
    {
        "id": "group-241109-1",
        "date": "2024-11-09",
        "displayDate": "2024년 11월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241109-1.jpg"
        ],
        "caption": "NOMAD Y2K<br>ㄴ 퍼가요~♡<br>ㄴ 퍼가요~♡",
        "type": "group",
        "rawDate": "241109",
        "postNum": 1
    },
    {
        "id": "group-241106",
        "date": "2024-11-06",
        "displayDate": "2024년 11월 6일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241106.jpeg"
        ],
        "caption": "NOMAD is here 📞 24) 11-06",
        "type": "group",
        "rawDate": "241106",
        "postNum": null
    },
    {
        "id": "group-241102",
        "date": "2024-11-02",
        "displayDate": "2024년 11월 2일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241102.jpg"
        ],
        "caption": "NOMAD is here 📞 24) 11-01",
        "type": "group",
        "rawDate": "241102",
        "postNum": null
    },
    {
        "id": "group-241101",
        "date": "2024-11-01",
        "displayDate": "2024년 11월 1일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241101.jpg"
        ],
        "caption": "NOMAD is here 📞 24) 10-31",
        "type": "group",
        "rawDate": "241101",
        "postNum": null
    },
    {
        "id": "group-241024",
        "date": "2024-10-24",
        "displayDate": "2024년 10월 24일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241024%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241024%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241024%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241024%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241024%20(5).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241024%20(6).mp4"
        ],
        "caption": "웃고 있는 노매드를 담았던 📷",
        "type": "group",
        "rawDate": "241024",
        "postNum": null
    },
    {
        "id": "group-241019-2",
        "date": "2024-10-19",
        "displayDate": "2024년 10월 19일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241019-2%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241019-2%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241019-2%20(3).jpg"
        ],
        "caption": "📞 Call Me Back with Music Bank",
        "type": "group",
        "rawDate": "241019",
        "postNum": 2
    },
    {
        "id": "group-241019-1",
        "date": "2024-10-19",
        "displayDate": "2024년 10월 19일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241019-1.jpg"
        ],
        "caption": "NOMAD is here 📞 24) 10-18",
        "type": "group",
        "rawDate": "241019",
        "postNum": 1
    },
    {
        "id": "group-241018",
        "date": "2024-10-18",
        "displayDate": "2024년 10월 18일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241018.jpg"
        ],
        "caption": "NOMAD is here 📞 24) 10-18",
        "type": "group",
        "rawDate": "241018",
        "postNum": null
    },
    {
        "id": "group-241017",
        "date": "2024-10-17",
        "displayDate": "2024년 10월 17일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241017%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241017%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241017%20(3).jpg"
        ],
        "caption": "📞 Call Me Back with Simply K-pop",
        "type": "group",
        "rawDate": "241017",
        "postNum": null
    },
    {
        "id": "group-241015",
        "date": "2024-10-15",
        "displayDate": "2024년 10월 15일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241015%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241015%20(2).jpg"
        ],
        "caption": "BGM : Call Me Back 💽",
        "type": "group",
        "rawDate": "241015",
        "postNum": null
    },
    {
        "id": "group-241013-2",
        "date": "2024-10-13",
        "displayDate": "2024년 10월 13일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241013-2%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241013-2%20(2).jpg"
        ],
        "caption": "캣잎 준호 🐈‍⬛<br>(원이는 촬영중🫣)",
        "type": "group",
        "rawDate": "241013",
        "postNum": 2
    },
    {
        "id": "group-241013-1",
        "date": "2024-10-13",
        "displayDate": "2024년 10월 13일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241013-1.jpg"
        ],
        "caption": "NOMAD is here 📞 24) 10-14",
        "type": "group",
        "rawDate": "241013",
        "postNum": 1
    },
    {
        "id": "group-241012",
        "date": "2024-10-12",
        "displayDate": "2024년 10월 12일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241012.jpg"
        ],
        "caption": "NOMAD is here 📞 24) 10-12",
        "type": "group",
        "rawDate": "241012",
        "postNum": null
    },
    {
        "id": "group-241011",
        "date": "2024-10-11",
        "displayDate": "2024년 10월 11일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241011%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241011%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241011%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241011%20(4).jpg"
        ],
        "caption": "어항안에 갇힌 도의🐟<br>홍도의 아웃! 홍도의 아웃!",
        "type": "group",
        "rawDate": "241011",
        "postNum": null
    },
    {
        "id": "group-241009-2",
        "date": "2024-10-09",
        "displayDate": "2024년 10월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241009-2.jpg"
        ],
        "caption": "NOMAD is here 📞 24) 10-09",
        "type": "group",
        "rawDate": "241009",
        "postNum": 2
    },
    {
        "id": "group-241009-1",
        "date": "2024-10-09",
        "displayDate": "2024년 10월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241009-1.jpg"
        ],
        "caption": "Call Me Back 드디어 컴백 📞😊",
        "type": "group",
        "rawDate": "241009",
        "postNum": 1
    },
    {
        "id": "group-241004",
        "date": "2024-10-04",
        "displayDate": "2024년 10월 4일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241004.jpg"
        ],
        "caption": "based on BASE 🖤",
        "type": "group",
        "rawDate": "241004",
        "postNum": null
    },
    {
        "id": "group-240928",
        "date": "2024-09-28",
        "displayDate": "2024년 9월 28일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240928%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240928%20(2).jpeg"
        ],
        "caption": "NOMAD 1st Single 【𝓒𝓪𝓵𝓵 𝓜𝓮 𝓑𝓪𝓬𝓴】<br><br>CONCEPT PHOTO #NOMAD<br><br>📞 2024.10.09 6PM (KST)",
        "type": "group",
        "rawDate": "240928",
        "postNum": null
    },
    {
        "id": "group-240927",
        "date": "2024-09-27",
        "displayDate": "2024년 9월 27일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240927%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240927%20(2).jpeg"
        ],
        "caption": "NOMAD 1st Single 【𝓒𝓪𝓵𝓵 𝓜𝓮 𝓑𝓪𝓬𝓴】<br><br>CONCEPT PHOTO #DOY<br><br>📞 2024.10.09 6PM (KST)",
        "type": "group",
        "rawDate": "240927",
        "postNum": null
    },
    {
        "id": "group-240920",
        "date": "2024-09-20",
        "displayDate": "2024년 9월 20일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240920.jpeg"
        ],
        "caption": "NOMAD 1st Single 【𝓒𝓪𝓵𝓵 𝓜𝓮 𝓑𝓪𝓬𝓴】<br><br>📞 2024.10.09 6PM (KST)",
        "type": "group",
        "rawDate": "240920",
        "postNum": null
    },
    {
        "id": "group-240916",
        "date": "2024-09-16",
        "displayDate": "2024년 9월 16일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240916.mp4"
        ],
        "caption": "Can you Call Me Back?",
        "type": "group",
        "rawDate": "240916",
        "postNum": null
    },
    {
        "id": "group-240914",
        "date": "2024-09-14",
        "displayDate": "2024년 9월 14일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240914.jpeg"
        ],
        "caption": "HAPPY 200 DAYS NOMAD!",
        "type": "group",
        "rawDate": "240914",
        "postNum": null
    },
    {
        "id": "group-240823",
        "date": "2024-08-23",
        "displayDate": "2024년 8월 23일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240823.jpg"
        ],
        "caption": "🥘 Made by ChefMAD",
        "type": "group",
        "rawDate": "240823",
        "postNum": null
    },
    {
        "id": "group-240815",
        "date": "2024-08-15",
        "displayDate": "2024년 8월 15일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240815.jpg"
        ],
        "caption": "NOMAD 2024 MZ FESTIVAL | 240815",
        "type": "group",
        "rawDate": "240815",
        "postNum": null
    },
    {
        "id": "group-240620",
        "date": "2024-06-20",
        "displayDate": "2024년 6월 20일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240620%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240620%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240620%20(3).jpg"
        ],
        "caption": "recuerdos de Mexico 📷",
        "type": "group",
        "rawDate": "240620",
        "postNum": null
    },
    {
        "id": "group-240617",
        "date": "2024-06-17",
        "displayDate": "2024년 6월 17일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240617%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240617%20(2).jpeg"
        ],
        "caption": "NOMAD 2024 K-BRAND EXPO IN MEXICO<br>Muchas gracias BASE Mexicana!",
        "type": "group",
        "rawDate": "240617",
        "postNum": null
    },
    {
        "id": "group-240606",
        "date": "2024-06-06",
        "displayDate": "2024년 6월 6일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240606.jpeg"
        ],
        "caption": "HAPPY 100 DAYS NOMAD!",
        "type": "group",
        "rawDate": "240606",
        "postNum": null
    },
    {
        "id": "group-240516",
        "date": "2024-05-16",
        "displayDate": "2024년 5월 16일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240516%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240516%20(2).jpeg"
        ],
        "caption": "NOMAD KMPF 2024 | 240516",
        "type": "group",
        "rawDate": "240516",
        "postNum": null
    },
    {
        "id": "group-240504",
        "date": "2024-05-04",
        "displayDate": "2024년 5월 4일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240504%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240504%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240504%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240504%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240504%20(5).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240504%20(6).jpg"
        ],
        "caption": "📸",
        "type": "group",
        "rawDate": "240504",
        "postNum": null
    },
    {
        "id": "group-240429",
        "date": "2024-04-29",
        "displayDate": "2024년 4월 29일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240429%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240429%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240429%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240429%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240429%20(5).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240429%20(6).jpg"
        ],
        "caption": "JAPAN SHOWCASE Behind the stage",
        "type": "group",
        "rawDate": "240429",
        "postNum": null
    },
    {
        "id": "group-240426",
        "date": "2024-04-26",
        "displayDate": "2024년 4월 26일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240426%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240426%20(2).jpeg"
        ],
        "caption": "NOMAD 2024 SHOWCASE IN JAPAN",
        "type": "group",
        "rawDate": "240426",
        "postNum": null
    },
    {
        "id": "group-240328",
        "date": "2024-03-28",
        "displayDate": "2024년 3월 28일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240328%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240328%20(2).jpeg"
        ],
        "caption": "NOMAD SHOW CHAMPION | 240327✨",
        "type": "group",
        "rawDate": "240328",
        "postNum": null
    },
    {
        "id": "group-240321",
        "date": "2024-03-21",
        "displayDate": "2024년 3월 21일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240321%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240321%20(2).jpeg"
        ],
        "caption": "NOMAD SHOW CHAMPION | 240320",
        "type": "group",
        "rawDate": "240321",
        "postNum": null
    },
    {
        "id": "group-240319",
        "date": "2024-03-19",
        "displayDate": "2024년 3월 19일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240319%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240319%20(2).jpeg"
        ],
        "caption": "NOMAD THE SHOW | 240319 🌟",
        "type": "group",
        "rawDate": "240319",
        "postNum": null
    },
    {
        "id": "group-240317",
        "date": "2024-03-17",
        "displayDate": "2024년 3월 17일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240317%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240317%20(2).jpeg"
        ],
        "caption": "NOMAD INKIGAYO | 240317 🎸",
        "type": "group",
        "rawDate": "240317",
        "postNum": null
    },
    {
        "id": "group-240316",
        "date": "2024-03-16",
        "displayDate": "2024년 3월 16일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240316.jpeg"
        ],
        "caption": "NOMAD SHOW! MUSIC CORE | 240316 🎼",
        "type": "group",
        "rawDate": "240316",
        "postNum": null
    },
    {
        "id": "group-240315",
        "date": "2024-03-15",
        "displayDate": "2024년 3월 15일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240315%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240315%20(2).jpeg"
        ],
        "caption": "NOMAD Music Bank | 240315 🎧",
        "type": "group",
        "rawDate": "240315",
        "postNum": null
    },
    {
        "id": "group-240314",
        "date": "2024-03-14",
        "displayDate": "2024년 3월 14일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240314%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240314%20(2).jpeg"
        ],
        "caption": "NOMAD SHOW CHAMPION | 240313 🎶",
        "type": "group",
        "rawDate": "240314",
        "postNum": null
    },
    {
        "id": "group-240312-2",
        "date": "2024-03-12",
        "displayDate": "2024년 3월 12일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240312-2%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240312-2%20(2).jpeg"
        ],
        "caption": "NOMAD THE SHOW | 240312 ✨",
        "type": "group",
        "rawDate": "240312",
        "postNum": 2
    },
    {
        "id": "group-240312-1",
        "date": "2024-03-12",
        "displayDate": "2024년 3월 12일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240312-1%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240312-1%20(2).jpeg"
        ],
        "caption": "NOMAD 노매드 1st EP <NOMAD><br>Cali ver<br>CONCEPT PHOTO 2<br><br>2024.03.13 WED 6PM (KST)<br>'California love' MV RELEASE",
        "type": "group",
        "rawDate": "240312",
        "postNum": 1
    },
    {
        "id": "group-240311",
        "date": "2024-03-11",
        "displayDate": "2024년 3월 11일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240311%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240311%20(2).jpeg"
        ],
        "caption": "NOMAD 노매드 1st EP <NOMAD><br>Cali ver<br>CONCEPT PHOTO 1<br><br>2024.03.13 WED 6PM (KST)<br>'California love' MV RELEASE",
        "type": "group",
        "rawDate": "240311",
        "postNum": null
    },
    {
        "id": "group-240309-2",
        "date": "2024-03-09",
        "displayDate": "2024년 3월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240309-2%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240309-2%20(2).jpeg"
        ],
        "caption": "3/9 쇼!음악중심",
        "type": "group",
        "rawDate": "240309",
        "postNum": 2
    },
    {
        "id": "group-240309-1",
        "date": "2024-03-09",
        "displayDate": "2024년 3월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240309-1.jpeg"
        ],
        "caption": "Swimmin' to you",
        "type": "group",
        "rawDate": "240309",
        "postNum": 1
    },
    {
        "id": "group-240308",
        "date": "2024-03-08",
        "displayDate": "2024년 3월 8일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240308%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240308%20(2).jpeg"
        ],
        "caption": "3/8 뮤직뱅크 💰",
        "type": "group",
        "rawDate": "240308",
        "postNum": null
    },
    {
        "id": "group-240307",
        "date": "2024-03-07",
        "displayDate": "2024년 3월 7일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240307%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240307%20(2).jpeg"
        ],
        "caption": "3/7 Mnet 두 번째 엠카운트다운💎",
        "type": "group",
        "rawDate": "240307",
        "postNum": null
    },
    {
        "id": "group-240305-2",
        "date": "2024-03-05",
        "displayDate": "2024년 3월 5일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240305-2%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240305-2%20(2).jpeg"
        ],
        "caption": "3/5 더쇼 Ⓜ️",
        "type": "group",
        "rawDate": "240305",
        "postNum": 2
    },
    {
        "id": "group-240305-1",
        "date": "2024-03-05",
        "displayDate": "2024년 3월 5일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240305-1%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240305-1%20(2).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240305-1%20(3).jpeg"
        ],
        "caption": "NOMAD Simply K-Pop | 240304 ⏯️",
        "type": "group",
        "rawDate": "240305",
        "postNum": 1
    },
    {
        "id": "group-240303",
        "date": "2024-03-03",
        "displayDate": "2024년 3월 3일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240303%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240303%20(2).jpeg"
        ],
        "caption": "NOMAD INKIGAYO | 240303 📸",
        "type": "group",
        "rawDate": "240303",
        "postNum": null
    },
    {
        "id": "group-240302-2",
        "date": "2024-03-02",
        "displayDate": "2024년 3월 2일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240302-2%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240302-2%20(2).jpeg"
        ],
        "caption": "NOMAD SHOW! MUSIC CORE | 240302 🎤",
        "type": "group",
        "rawDate": "240302",
        "postNum": 2
    },
    {
        "id": "group-240302-1",
        "date": "2024-03-02",
        "displayDate": "2024년 3월 2일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240302-1%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240302-1%20(2).jpeg"
        ],
        "caption": "NOMAD Music Bank | 240301 📷",
        "type": "group",
        "rawDate": "240302",
        "postNum": 1
    },
    {
        "id": "group-240301",
        "date": "2024-03-01",
        "displayDate": "2024년 3월 1일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240301.jpeg"
        ],
        "caption": "NOMAD Mcountdown | 240229✨",
        "type": "group",
        "rawDate": "240301",
        "postNum": null
    },
    {
        "id": "group-240229",
        "date": "2024-02-29",
        "displayDate": "2024년 2월 29일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240229%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240229%20(2).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240229%20(3).jpeg"
        ],
        "caption": "BASE 여러분,<br>NOMAD의 여정이 이제 시작되었습니다.<br>첫 발걸음을 함께해 주신 BASE 여러분께 깊은 감사를 드립니다.<br><br>‘BASE’라는 소중한 팬네임은<br>다섯 멤버들의 아이디어에서 시작되었습니다.<br><br>NOMAD의 ‘Basecamp’로써, 다섯 명의 NOMAD가 향하는 방향을 알려주기도 하고<br>다섯 명의 NOMAD가 향하는 목표를 함께 오르는 존재가 되어주시길 바라는 마음을 담아 탄생한 이름입니다.<br><br>또한 NOMAD의 근간이 되는 존재로서,<br>또 다른 ‘NOMAD’의 여섯 번째 멤버로서 앞으로도 계속 이 여정에 함께해 주시길 바랍니다.<br>감사합니다.<br><br>NOMAD & NOMAD Entertainment 드림",
        "type": "group",
        "rawDate": "240229",
        "postNum": null
    },
    {
        "id": "group-240213",
        "date": "2024-02-13",
        "displayDate": "2024년 2월 13일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240213%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240213%20(2).jpeg"
        ],
        "caption": "노매드 1st EP <NOMAD><br>CONCEPT PHOTO 2 #DOY<br><br>2024.02.28 WED 6PM (KST)<br>1st EP <NOMAD> RELEASE",
        "type": "group",
        "rawDate": "240213",
        "postNum": null
    },
    {
        "id": "group-240212",
        "date": "2024-02-12",
        "displayDate": "2024년 2월 12일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240212%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240212%20(2).jpeg"
        ],
        "caption": "NOMAD 노매드 1st EP <NOMAD><br>CONCEPT PHOTO 1<br><br>2024.02.28 WED 6PM (KST)<br>1st EP <NOMAD> RELEASE",
        "type": "group",
        "rawDate": "240212",
        "postNum": null
    },
    {
        "id": "group-240210",
        "date": "2024-02-10",
        "displayDate": "2024년 2월 10일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240210%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240210%20(2).jpeg"
        ],
        "caption": "NOMAD 노매드<br>MOOD IMAGE 1 #DOY",
        "type": "group",
        "rawDate": "240210",
        "postNum": null
    },
    {
        "id": "group-240208",
        "date": "2024-02-08",
        "displayDate": "2024년 2월 8일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240208.jpeg"
        ],
        "caption": "NOMAD 노매드<br>DEBUT CONCEPT POSTER #NOMAD",
        "type": "group",
        "rawDate": "240208",
        "postNum": null
    },
    {
        "id": "group-240206-3",
        "date": "2024-02-06",
        "displayDate": "2024년 2월 6일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240206-3.jpeg"
        ],
        "caption": "NOMAD 노매드<br>TEASER IMAGE #2<br><br>2024.02.28<br>1ST EP \"NOMAD\" RELEASE",
        "type": "group",
        "rawDate": "240206",
        "postNum": 3
    },
    {
        "id": "group-240206-2",
        "date": "2024-02-06",
        "displayDate": "2024년 2월 6일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240206-2.jpeg"
        ],
        "caption": "NOMAD 노매드<br>TEASER IMAGE #2<br><br>2024.02.28<br>1ST EP \"NOMAD\" RELEASE",
        "type": "group",
        "rawDate": "240206",
        "postNum": 2
    },
    {
        "id": "group-240206-1",
        "date": "2024-02-06",
        "displayDate": "2024년 2월 6일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240206-1.jpeg"
        ],
        "caption": "NOMAD 노매드<br>TEASER IMAGE #2<br><br>2024.02.28<br>1ST EP \"NOMAD\" RELEASE",
        "type": "group",
        "rawDate": "240206",
        "postNum": 1
    },
    {
        "id": "group-240205-3",
        "date": "2024-02-05",
        "displayDate": "2024년 2월 5일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240205-3.jpeg"
        ],
        "caption": "NOMAD 노매드<br>TEASER IMAGE #1<br><br>2024.02.28<br>1ST EP \"NOMAD\" RELEASE",
        "type": "group",
        "rawDate": "240205",
        "postNum": 3
    },
    {
        "id": "group-240205-2",
        "date": "2024-02-05",
        "displayDate": "2024년 2월 5일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240205-2.jpeg"
        ],
        "caption": "NOMAD 노매드<br>TEASER IMAGE #1<br><br>2024.02.28<br>1ST EP \"NOMAD\" RELEASE",
        "type": "group",
        "rawDate": "240205",
        "postNum": 2
    },
    {
        "id": "group-240205-1",
        "date": "2024-02-05",
        "displayDate": "2024년 2월 5일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240205-1.jpeg"
        ],
        "caption": "NOMAD 노매드<br>TEASER IMAGE #1<br><br>2024.02.28<br>1ST EP \"NOMAD\" RELEASE",
        "type": "group",
        "rawDate": "240205",
        "postNum": 1
    },
    {
        "id": "group-240119",
        "date": "2024-01-19",
        "displayDate": "2024년 1월 19일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240119%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240119%20(2).jpg"
        ],
        "caption": "🎬",
        "type": "group",
        "rawDate": "240119",
        "postNum": null
    },
    {
        "id": "group-240118-2",
        "date": "2024-01-18",
        "displayDate": "2024년 1월 18일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240118-2.jpg"
        ],
        "caption": "Runnnnn",
        "type": "group",
        "rawDate": "240118",
        "postNum": 2
    },
    {
        "id": "group-240118-1",
        "date": "2024-01-18",
        "displayDate": "2024년 1월 18일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240118-1.jpg"
        ],
        "caption": "Night walk",
        "type": "group",
        "rawDate": "240118",
        "postNum": 1
    },
    {
        "id": "group-240101",
        "date": "2024-01-01",
        "displayDate": "2024년 1월 1일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240101%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240101%20(2).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240101%20(3).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240101%20(4).jpeg"
        ],
        "caption": "📷 Behind cut #도의<br>Watch the 'Lights on' Performance Video on ▶ Youtube",
        "type": "group",
        "rawDate": "240101",
        "postNum": null
    },
    {
        "id": "group-231230",
        "date": "2023-12-30",
        "displayDate": "2023년 12월 30일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/231230%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/231230%20(2).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/231230%20(3).jpeg"
        ],
        "caption": "📷 Behind cut #노매드<br>Watch the 'Lights on' Performance Video on ▶ Youtube",
        "type": "group",
        "rawDate": "231230",
        "postNum": null
    },
    {
        "id": "group-231228",
        "date": "2023-12-28",
        "displayDate": "2023년 12월 28일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/231228%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/231228%20(2).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/231228%20(3).jpeg"
        ],
        "caption": "📷 Behind cut #도의<br>Watch the 'Lights on' Performance Video on ▶ Youtube",
        "type": "group",
        "rawDate": "231228",
        "postNum": null
    },
    {
        "id": "group-231222",
        "date": "2023-12-22",
        "displayDate": "2023년 12월 22일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/231222%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/231222%20(2).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/231222%20(3).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/231222%20(4).jpeg"
        ],
        "caption": "도의 (DOY)<br><br>2023.12.27 NOMAD 1st ep B-side Track 'Lights On'<br>Performance Video Pre-release",
        "type": "group",
        "rawDate": "231222",
        "postNum": null
    }
];

// 스토리 탭 (insta-story)
export const storyPosts = [
    {
        "id": "story-250503",
        "date": "2025-05-03",
        "displayDate": "2025년 5월 3일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250503%20(1).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250503%20(2).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250503%20(3).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250503%20(4).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250503%20(5).mp4"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "250503",
        "postNum": null
    },
    {
        "id": "story-250312",
        "date": "2025-03-12",
        "displayDate": "2025년 3월 12일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250312.mp4"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "250312",
        "postNum": null
    },
    {
        "id": "story-250311",
        "date": "2025-03-11",
        "displayDate": "2025년 3월 11일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250311.jpg"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "250311",
        "postNum": null
    },
    {
        "id": "story-250310-2",
        "date": "2025-03-10",
        "displayDate": "2025년 3월 10일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250310-2.jpg"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "250310",
        "postNum": 2
    },
    {
        "id": "story-250310-1",
        "date": "2025-03-10",
        "displayDate": "2025년 3월 10일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250310-1%20(1).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250310-1%20(2).mp4"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "250310",
        "postNum": 1
    },
    {
        "id": "story-250308",
        "date": "2025-03-08",
        "displayDate": "2025년 3월 8일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250308%20(1).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250308%20(2).mp4"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "250308",
        "postNum": null
    },
    {
        "id": "story-250307",
        "date": "2025-03-07",
        "displayDate": "2025년 3월 7일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250307%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250307%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250307%20(3).jpg"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "250307",
        "postNum": null
    },
    {
        "id": "story-250306",
        "date": "2025-03-06",
        "displayDate": "2025년 3월 6일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250306.mp4"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "250306",
        "postNum": null
    },
    {
        "id": "story-250305",
        "date": "2025-03-05",
        "displayDate": "2025년 3월 5일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250305.mp4"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "250305",
        "postNum": null
    },
    {
        "id": "story-250304",
        "date": "2025-03-04",
        "displayDate": "2025년 3월 4일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250304.mp4"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "250304",
        "postNum": null
    },
    {
        "id": "story-250215",
        "date": "2025-02-15",
        "displayDate": "2025년 2월 15일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250215%20(1).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250215%20(2).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250215%20(3).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250215%20(4).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250215%20(5).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250215%20(6).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250215%20(7).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250215%20(8).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250215%20(9).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250215%20(10).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250215%20(11).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250215%20(12).mp4"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "250215",
        "postNum": null
    },
    {
        "id": "story-250212",
        "date": "2025-02-12",
        "displayDate": "2025년 2월 12일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250212.mp4"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "250212",
        "postNum": null
    },
    {
        "id": "story-250209",
        "date": "2025-02-09",
        "displayDate": "2025년 2월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/250209.jpg"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "250209",
        "postNum": null
    },
    {
        "id": "story-241224",
        "date": "2024-12-24",
        "displayDate": "2024년 12월 24일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/241224%20(1).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/241224%20(2).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/241224%20(3).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/241224%20(4).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/241224%20(5).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/241224%20(6).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/241224%20(7).mp4"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "241224",
        "postNum": null
    },
    {
        "id": "story-241220",
        "date": "2024-12-20",
        "displayDate": "2024년 12월 20일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/241220%20(1).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/241220%20(2).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/241220%20(3).mp4"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "241220",
        "postNum": null
    },
    {
        "id": "story-241117",
        "date": "2024-11-17",
        "displayDate": "2024년 11월 17일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/241117%20(1).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/241117%20(2).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/241117%20(3).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/241117%20(4).mp4"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "241117",
        "postNum": null
    },
    {
        "id": "story-241013",
        "date": "2024-10-13",
        "displayDate": "2024년 10월 13일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/241013%20(1).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/241013%20(2).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/241013%20(3).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/241013%20(4).mp4"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "241013",
        "postNum": null
    },
    {
        "id": "story-241012",
        "date": "2024-10-12",
        "displayDate": "2024년 10월 12일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/241012.mp4"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "241012",
        "postNum": null
    },
    {
        "id": "story-241009",
        "date": "2024-10-09",
        "displayDate": "2024년 10월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/241009.jpg"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "241009",
        "postNum": null
    },
    {
        "id": "story-240509",
        "date": "2024-05-09",
        "displayDate": "2024년 5월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/240509.mp4"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "240509",
        "postNum": null
    },
    {
        "id": "story-240425",
        "date": "2024-04-25",
        "displayDate": "2024년 4월 25일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/240425%20(1).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/240425%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/240425%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/240425%20(4).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/240425%20(5).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/240425%20(6).mp4"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "240425",
        "postNum": null
    },
    {
        "id": "story-240423",
        "date": "2024-04-23",
        "displayDate": "2024년 4월 23일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/240423%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/240423%20(2).mp4"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "240423",
        "postNum": null
    },
    {
        "id": "story-240420",
        "date": "2024-04-20",
        "displayDate": "2024년 4월 20일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-story/240420.mp4"
        ],
        "caption": "",
        "type": "story",
        "rawDate": "240420",
        "postNum": null
    }
];

// 리포스트 탭 (photo + group 합침, 같은 날짜면 group 우선)
export const repostPosts = [
    {
        "id": "repost-0",
        "date": "2025-11-24",
        "displayDate": "2025년 11월 24일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251124-2%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251124-2%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251124-2%20(3).jpg"
        ],
        "caption": "NOMAD : NO PLAN BEHIND PHOTO",
        "type": "group",
        "rawDate": "251124",
        "postNum": 2,
        "originalId": "group-251124-2"
    },
    {
        "id": "repost-1",
        "date": "2025-11-24",
        "displayDate": "2025년 11월 24일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251124-1%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251124-1%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251124-1%20(3).jpg"
        ],
        "caption": "NOMAD : NO PLAN BEHIND PHOTO",
        "type": "group",
        "rawDate": "251124",
        "postNum": 1,
        "originalId": "group-251124-1"
    },
    {
        "id": "repost-2",
        "date": "2025-10-28",
        "displayDate": "2025년 10월 28일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251028.mp4"
        ],
        "caption": "NOMAD x NUYH NEWYORK @nuyh.newyork",
        "type": "group",
        "rawDate": "251028",
        "postNum": null,
        "originalId": "group-251028"
    },
    {
        "id": "repost-3",
        "date": "2025-10-24",
        "displayDate": "2025년 10월 24일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251024%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251024%20(2).jpg"
        ],
        "caption": "NUYH NEWYORK 26 S/S Collection 《SHA:DOW | 영影》 | @nuyh.newyork",
        "type": "group",
        "rawDate": "251024",
        "postNum": null,
        "originalId": "group-251024"
    },
    {
        "id": "repost-4",
        "date": "2025-10-17",
        "displayDate": "2025년 10월 17일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251017.mp4"
        ],
        "caption": "NOMAD x Fashion Hankook @fashion_sportshankook",
        "type": "group",
        "rawDate": "251017",
        "postNum": null,
        "originalId": "group-251017"
    },
    {
        "id": "repost-5",
        "date": "2025-10-10",
        "displayDate": "2025년 10월 10일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251010%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251010%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251010%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251010%20(4).jpg"
        ],
        "caption": "🔥",
        "type": "group",
        "rawDate": "251010",
        "postNum": null,
        "originalId": "group-251010"
    },
    {
        "id": "repost-6",
        "date": "2025-10-05",
        "displayDate": "2025년 10월 5일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/251005.mp4"
        ],
        "caption": "DOY's first solo stage in C.ATworkFesta @c.atworkfesta @_erer.official",
        "type": "group",
        "rawDate": "251005",
        "postNum": null,
        "originalId": "group-251005"
    },
    {
        "id": "repost-7",
        "date": "2025-09-30",
        "displayDate": "2025년 9월 30일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250930%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250930%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250930%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250930%20(4).jpg"
        ],
        "caption": "GET THAT",
        "type": "photo",
        "rawDate": "250930",
        "postNum": null,
        "originalId": "photo-250930"
    },
    {
        "id": "repost-8",
        "date": "2025-09-28",
        "displayDate": "2025년 9월 28일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250928%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250928%20(2).jpeg"
        ],
        "caption": "2025 C.AT WORK FESTA | ERER @_erer.official",
        "type": "group",
        "rawDate": "250928",
        "postNum": null,
        "originalId": "group-250928"
    },
    {
        "id": "repost-9",
        "date": "2025-09-23",
        "displayDate": "2025년 9월 23일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250923%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250923%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250923%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250923%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250923%20(5).jpg"
        ],
        "caption": "😶",
        "type": "photo",
        "rawDate": "250923",
        "postNum": null,
        "originalId": "photo-250923"
    },
    {
        "id": "repost-10",
        "date": "2025-09-14",
        "displayDate": "2025년 9월 14일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250914%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250914%20(2).jpg"
        ],
        "caption": "1-2",
        "type": "photo",
        "rawDate": "250914",
        "postNum": null,
        "originalId": "photo-250914"
    },
    {
        "id": "repost-11",
        "date": "2025-08-23",
        "displayDate": "2025년 8월 23일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250823%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250823%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250823%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250823%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250823%20(5).jpg"
        ],
        "caption": "📸📸📸📸📸",
        "type": "photo",
        "rawDate": "250823",
        "postNum": null,
        "originalId": "photo-250823"
    },
    {
        "id": "repost-12",
        "date": "2025-08-14",
        "displayDate": "2025년 8월 14일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250814%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250814%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250814%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250814%20(4).jpg"
        ],
        "caption": "👀",
        "type": "photo",
        "rawDate": "250814",
        "postNum": null,
        "originalId": "photo-250814"
    },
    {
        "id": "repost-13",
        "date": "2025-08-07",
        "displayDate": "2025년 8월 7일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250807%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250807%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250807%20(3).jpg"
        ],
        "caption": "go on?",
        "type": "photo",
        "rawDate": "250807",
        "postNum": null,
        "originalId": "photo-250807"
    },
    {
        "id": "repost-14",
        "date": "2025-07-20",
        "displayDate": "2025년 7월 20일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250720%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250720%20(2).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250720%20(3).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250720%20(4).mp4",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250720%20(5).mp4"
        ],
        "caption": "All India K-POP Contest 2025 🇮🇳 दोबारा जल्दी मिलेंगे ❤️‍🔥",
        "type": "group",
        "rawDate": "250720",
        "postNum": null,
        "originalId": "group-250720"
    },
    {
        "id": "repost-15",
        "date": "2025-07-16",
        "displayDate": "2025년 7월 16일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250716%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250716%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250716%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250716%20(4).jpg"
        ],
        "caption": "♾️",
        "type": "photo",
        "rawDate": "250716",
        "postNum": null,
        "originalId": "photo-250716"
    },
    {
        "id": "repost-16",
        "date": "2025-07-04",
        "displayDate": "2025년 7월 4일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250704%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250704%20(2).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250704%20(3).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250704%20(4).jpeg"
        ],
        "caption": "🎧🎵",
        "type": "photo",
        "rawDate": "250704",
        "postNum": null,
        "originalId": "photo-250704"
    },
    {
        "id": "repost-17",
        "date": "2025-06-17",
        "displayDate": "2025년 6월 17일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250617%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250617%20(2).jpg"
        ],
        "caption": "BOF 🌊",
        "type": "group",
        "rawDate": "250617",
        "postNum": null,
        "originalId": "group-250617"
    },
    {
        "id": "repost-18",
        "date": "2025-06-13",
        "displayDate": "2025년 6월 13일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250613.jpg"
        ],
        "caption": "2025 BUSAN ONEASIA FESTIVAL BIG CONCERT SHOWCASE",
        "type": "group",
        "rawDate": "250613",
        "postNum": null,
        "originalId": "group-250613"
    },
    {
        "id": "repost-19",
        "date": "2025-06-12",
        "displayDate": "2025년 6월 12일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250612.jpeg"
        ],
        "caption": "NOMAD X 撕拉片📸",
        "type": "group",
        "rawDate": "250612",
        "postNum": null,
        "originalId": "group-250612"
    },
    {
        "id": "repost-20",
        "date": "2025-06-10",
        "displayDate": "2025년 6월 10일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250610.jpg"
        ],
        "caption": "👀",
        "type": "photo",
        "rawDate": "250610",
        "postNum": null,
        "originalId": "photo-250610"
    },
    {
        "id": "repost-21",
        "date": "2025-05-04",
        "displayDate": "2025년 5월 4일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250504%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250504%20(2).jpg"
        ],
        "caption": "🍃🍃🍃",
        "type": "photo",
        "rawDate": "250504",
        "postNum": null,
        "originalId": "photo-250504"
    },
    {
        "id": "repost-22",
        "date": "2025-05-03",
        "displayDate": "2025년 5월 3일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250503.jpg"
        ],
        "caption": "NOMAD is here #한강 🎵 25) 05-03",
        "type": "group",
        "rawDate": "250503",
        "postNum": null,
        "originalId": "group-250503"
    },
    {
        "id": "repost-23",
        "date": "2025-04-22",
        "displayDate": "2025년 4월 22일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250422%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250422%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250422%20(3).jpg"
        ],
        "caption": "⚠️",
        "type": "photo",
        "rawDate": "250422",
        "postNum": null,
        "originalId": "photo-250422"
    },
    {
        "id": "repost-24",
        "date": "2025-03-27",
        "displayDate": "2025년 3월 27일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250327%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250327%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250327%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250327%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250327%20(5).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250327%20(6).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250327%20(7).jpg"
        ],
        "caption": "🔶🔶🔶",
        "type": "photo",
        "rawDate": "250327",
        "postNum": null,
        "originalId": "photo-250327"
    },
    {
        "id": "repost-25",
        "date": "2025-03-23",
        "displayDate": "2025년 3월 23일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250323%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250323%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250323%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250323%20(4).jpg"
        ],
        "caption": "날씨 좋음 🤓",
        "type": "photo",
        "rawDate": "250323",
        "postNum": null,
        "originalId": "photo-250323"
    },
    {
        "id": "repost-26",
        "date": "2025-03-18",
        "displayDate": "2025년 3월 18일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250318%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250318%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250318%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250318%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250318%20(5).jpg"
        ],
        "caption": "✌️✌️",
        "type": "photo",
        "rawDate": "250318",
        "postNum": null,
        "originalId": "photo-250318"
    },
    {
        "id": "repost-27",
        "date": "2025-03-16",
        "displayDate": "2025년 3월 16일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250316.jpeg"
        ],
        "caption": "NOMAD LIVE IN TOKYO | 250316",
        "type": "group",
        "rawDate": "250316",
        "postNum": null,
        "originalId": "group-250316"
    },
    {
        "id": "repost-28",
        "date": "2025-03-15",
        "displayDate": "2025년 3월 15일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250315.jpeg"
        ],
        "caption": "NOMAD LIVE IN TOKYO | 250315",
        "type": "group",
        "rawDate": "250315",
        "postNum": null,
        "originalId": "group-250315"
    },
    {
        "id": "repost-29",
        "date": "2025-03-14",
        "displayDate": "2025년 3월 14일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250314.jpeg"
        ],
        "caption": "NOMAD LIVE IN TOKYO | 250314",
        "type": "group",
        "rawDate": "250314",
        "postNum": null,
        "originalId": "group-250314"
    },
    {
        "id": "repost-30",
        "date": "2025-03-11",
        "displayDate": "2025년 3월 11일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250311%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250311%20(2).jpg"
        ],
        "caption": "NOMAD is here in TOKYO TOWER 🗼",
        "type": "group",
        "rawDate": "250311",
        "postNum": null,
        "originalId": "group-250311"
    },
    {
        "id": "repost-31",
        "date": "2025-03-11",
        "displayDate": "2025년 3월 11일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250311%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250311%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250311%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250311%20(4).jpg"
        ],
        "caption": "👓🎤🎶",
        "type": "photo",
        "rawDate": "250311",
        "postNum": null,
        "originalId": "photo-250311"
    },
    {
        "id": "repost-32",
        "date": "2025-03-10",
        "displayDate": "2025년 3월 10일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250310.jpeg"
        ],
        "caption": "NOMAD LIVE IN TOKYO | 250309",
        "type": "group",
        "rawDate": "250310",
        "postNum": null,
        "originalId": "group-250310"
    },
    {
        "id": "repost-33",
        "date": "2025-03-08",
        "displayDate": "2025년 3월 8일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250308.jpg"
        ],
        "caption": "NOMAD LIVE IN TOKYO | 250308",
        "type": "group",
        "rawDate": "250308",
        "postNum": null,
        "originalId": "group-250308"
    },
    {
        "id": "repost-34",
        "date": "2025-02-28",
        "displayDate": "2025년 2월 28일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250228.jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250228%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250228%20(2).jpg"
        ],
        "caption": "𝑁𝑂𝑀𝐴𝐷 𝐷𝐸𝐵𝑈𝑇 1𝑠𝑡 𝐴𝑛𝑛𝑖𝑣𝑒𝑟𝑠𝑎𝑟𝑦 🎈",
        "type": "group",
        "rawDate": "250228",
        "postNum": null,
        "originalId": "group-250228"
    },
    {
        "id": "repost-35",
        "date": "2025-02-19",
        "displayDate": "2025년 2월 19일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250219%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250219%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250219%20(3).jpg"
        ],
        "caption": "in JAKARTA",
        "type": "photo",
        "rawDate": "250219",
        "postNum": null,
        "originalId": "photo-250219"
    },
    {
        "id": "repost-36",
        "date": "2025-02-16",
        "displayDate": "2025년 2월 16일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250216.jpeg"
        ],
        "caption": "NOMAD Nonsan Strawberry Festival in Jakarta",
        "type": "group",
        "rawDate": "250216",
        "postNum": null,
        "originalId": "group-250216"
    },
    {
        "id": "repost-37",
        "date": "2025-02-10",
        "displayDate": "2025년 2월 10일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250210%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250210%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250210%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250210%20(4).jpg"
        ],
        "caption": "Doy was in SFW",
        "type": "photo",
        "rawDate": "250210",
        "postNum": null,
        "originalId": "photo-250210"
    },
    {
        "id": "repost-38",
        "date": "2025-02-09",
        "displayDate": "2025년 2월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250209%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250209%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250209%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250209%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250209%20(5).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250209%20(6).jpg"
        ],
        "caption": "2025 F/W SeoulFashionWeek : (Corp.) Gravity , @urbansavvy_official",
        "type": "group",
        "rawDate": "250209",
        "postNum": null,
        "originalId": "group-250209"
    },
    {
        "id": "repost-39",
        "date": "2025-02-09",
        "displayDate": "2025년 2월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250209%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250209%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/250209%20(3).jpg"
        ],
        "caption": "잊지 못할 CARNIVAL",
        "type": "photo",
        "rawDate": "250209",
        "postNum": null,
        "originalId": "photo-250209"
    },
    {
        "id": "repost-40",
        "date": "2025-02-08",
        "displayDate": "2025년 2월 8일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250208-2.jpg"
        ],
        "caption": "NOMAD 1ST FAN CONCERT <CARNIVAL> <br><br>영원히 노매드만을 위한 카니발을 만들어줄게🤍",
        "type": "group",
        "rawDate": "250208",
        "postNum": 2,
        "originalId": "group-250208-2"
    },
    {
        "id": "repost-41",
        "date": "2025-02-08",
        "displayDate": "2025년 2월 8일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250208-1%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250208-1%20(2).jpeg"
        ],
        "caption": "NOMAD 1ST FAN CONCERT <CARNIVAL> 🎆",
        "type": "group",
        "rawDate": "250208",
        "postNum": 1,
        "originalId": "group-250208-1"
    },
    {
        "id": "repost-42",
        "date": "2025-02-07",
        "displayDate": "2025년 2월 7일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250207%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250207%20(2).jpg"
        ],
        "caption": "2025 F/W SeoulFashionWeek : DAILY MIRROR",
        "type": "group",
        "rawDate": "250207",
        "postNum": null,
        "originalId": "group-250207"
    },
    {
        "id": "repost-43",
        "date": "2025-02-01",
        "displayDate": "2025년 2월 1일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250201%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250201%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250201%20(3).jpg"
        ],
        "caption": "You are my carnival 🎆",
        "type": "group",
        "rawDate": "250201",
        "postNum": null,
        "originalId": "group-250201"
    },
    {
        "id": "repost-44",
        "date": "2025-01-31",
        "displayDate": "2025년 1월 31일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250131%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250131%20(2).jpg"
        ],
        "caption": "분(위기) 좋(은) 카니발 🎇",
        "type": "group",
        "rawDate": "250131",
        "postNum": null,
        "originalId": "group-250131"
    },
    {
        "id": "repost-45",
        "date": "2025-01-22",
        "displayDate": "2025년 1월 22일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250122%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250122%20(2).jpeg"
        ],
        "caption": "NOMAD 1ST FAN CONCERT <CARNIVAL> POSTER<br>#도의 #DOY<br><br>🗓 2025.02.08. SAT 7PM (KST)<br><br>🎆 SHOWKING K-POP CENTER<br>🎫 b.stage+",
        "type": "group",
        "rawDate": "250122",
        "postNum": null,
        "originalId": "group-250122"
    },
    {
        "id": "repost-46",
        "date": "2025-01-09",
        "displayDate": "2025년 1월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250109%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/250109%20(2).jpg"
        ],
        "caption": "Team",
        "type": "group",
        "rawDate": "250109",
        "postNum": null,
        "originalId": "group-250109"
    },
    {
        "id": "repost-47",
        "date": "2024-12-26",
        "displayDate": "2024년 12월 26일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241226%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241226%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241226%20(3).jpg"
        ],
        "caption": "끄적끄적 ",
        "type": "photo",
        "rawDate": "241226",
        "postNum": null,
        "originalId": "photo-241226"
    },
    {
        "id": "repost-48",
        "date": "2024-12-25",
        "displayDate": "2024년 12월 25일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241225.jpg"
        ],
        "caption": "🎄Merry Christmas🎄",
        "type": "group",
        "rawDate": "241225",
        "postNum": null,
        "originalId": "group-241225"
    },
    {
        "id": "repost-49",
        "date": "2024-12-24",
        "displayDate": "2024년 12월 24일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241224%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241224%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241224%20(3).jpg"
        ],
        "caption": "NOMAD is here #school 📞  24) 12-24<br><덕성여자고등학교🏫> & <한성여자고등학교🏫>",
        "type": "group",
        "rawDate": "241224",
        "postNum": null,
        "originalId": "group-241224"
    },
    {
        "id": "repost-50",
        "date": "2024-12-23",
        "displayDate": "2024년 12월 23일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241223%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241223%20(2).jpg"
        ],
        "caption": "🖤 𝐍𝐎𝐌𝐀𝐃 𝐃𝐄𝐁𝐔𝐓 𝟑𝟎𝟎𝐃𝐀𝐘𝐒 🖤",
        "type": "group",
        "rawDate": "241223",
        "postNum": null,
        "originalId": "group-241223"
    },
    {
        "id": "repost-51",
        "date": "2024-12-23",
        "displayDate": "2024년 12월 23일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241223%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241223%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241223%20(3).jpg"
        ],
        "caption": "🎄🎄",
        "type": "photo",
        "rawDate": "241223",
        "postNum": null,
        "originalId": "photo-241223"
    },
    {
        "id": "repost-52",
        "date": "2024-12-20",
        "displayDate": "2024년 12월 20일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241220.jpg"
        ],
        "caption": "NOMAD is here #school 📞 24) 12-20<br><동일여자고등학교🏫>",
        "type": "group",
        "rawDate": "241220",
        "postNum": null,
        "originalId": "group-241220"
    },
    {
        "id": "repost-53",
        "date": "2024-12-16",
        "displayDate": "2024년 12월 16일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241216%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241216%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241216%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241216%20(4).jpg"
        ],
        "caption": "💤💤💤",
        "type": "photo",
        "rawDate": "241216",
        "postNum": null,
        "originalId": "photo-241216"
    },
    {
        "id": "repost-54",
        "date": "2024-12-14",
        "displayDate": "2024년 12월 14일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241214.jpg"
        ],
        "caption": "2024 GLOBAL INFLUENCER EXPO 📞 24) 12-14",
        "type": "group",
        "rawDate": "241214",
        "postNum": null,
        "originalId": "group-241214"
    },
    {
        "id": "repost-55",
        "date": "2024-12-13",
        "displayDate": "2024년 12월 13일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241213.jpeg"
        ],
        "caption": "NOMAD Christmas <MISTLETOE.cover> FILM MOOD 📷",
        "type": "group",
        "rawDate": "241213",
        "postNum": null,
        "originalId": "group-241213"
    },
    {
        "id": "repost-56",
        "date": "2024-12-05",
        "displayDate": "2024년 12월 5일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241205%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241205%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241205%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241205%20(4).jpg"
        ],
        "caption": "☀️☀️",
        "type": "photo",
        "rawDate": "241205",
        "postNum": null,
        "originalId": "photo-241205"
    },
    {
        "id": "repost-57",
        "date": "2024-11-27",
        "displayDate": "2024년 11월 27일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241127%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241127%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241127%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241127%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241127%20(5).jpg"
        ],
        "caption": "❄️❄️❄️",
        "type": "photo",
        "rawDate": "241127",
        "postNum": null,
        "originalId": "photo-241127"
    },
    {
        "id": "repost-58",
        "date": "2024-11-25",
        "displayDate": "2024년 11월 25일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241125%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241125%20(2).jpg"
        ],
        "caption": "All BLACK",
        "type": "photo",
        "rawDate": "241125",
        "postNum": null,
        "originalId": "photo-241125"
    },
    {
        "id": "repost-59",
        "date": "2024-11-23",
        "displayDate": "2024년 11월 23일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241123.jpg"
        ],
        "caption": "Suit MAD 😎",
        "type": "group",
        "rawDate": "241123",
        "postNum": null,
        "originalId": "group-241123"
    },
    {
        "id": "repost-60",
        "date": "2024-11-17",
        "displayDate": "2024년 11월 17일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241117%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241117%20(2).jpg"
        ],
        "caption": "NOMAD is here 24) 11-16",
        "type": "group",
        "rawDate": "241117",
        "postNum": null,
        "originalId": "group-241117"
    },
    {
        "id": "repost-61",
        "date": "2024-11-17",
        "displayDate": "2024년 11월 17일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241117%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241117%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241117%20(3).jpg"
        ],
        "caption": "DOY was here in Jakarta 🇮🇩",
        "type": "photo",
        "rawDate": "241117",
        "postNum": null,
        "originalId": "photo-241117"
    },
    {
        "id": "repost-62",
        "date": "2024-11-12",
        "displayDate": "2024년 11월 12일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241112%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241112%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241112%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241112%20(4).jpg"
        ],
        "caption": "🍁🍂",
        "type": "photo",
        "rawDate": "241112",
        "postNum": null,
        "originalId": "photo-241112"
    },
    {
        "id": "repost-63",
        "date": "2024-11-09",
        "displayDate": "2024년 11월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241109-2%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241109-2%20(2).jpg"
        ],
        "caption": "NOMAD is here #Hongdae 📞 24) 11-09",
        "type": "group",
        "rawDate": "241109",
        "postNum": 2,
        "originalId": "group-241109-2"
    },
    {
        "id": "repost-64",
        "date": "2024-11-09",
        "displayDate": "2024년 11월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241109-1.jpg"
        ],
        "caption": "NOMAD Y2K<br>ㄴ 퍼가요~♡<br>ㄴ 퍼가요~♡",
        "type": "group",
        "rawDate": "241109",
        "postNum": 1,
        "originalId": "group-241109-1"
    },
    {
        "id": "repost-65",
        "date": "2024-11-09",
        "displayDate": "2024년 11월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241109%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241109%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241109%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241109%20(4).jpg"
        ],
        "caption": "DO_Y_Vibe",
        "type": "photo",
        "rawDate": "241109",
        "postNum": null,
        "originalId": "photo-241109"
    },
    {
        "id": "repost-66",
        "date": "2024-11-07",
        "displayDate": "2024년 11월 7일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241107%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241107%20(2).jpg"
        ],
        "caption": "🏊☀️",
        "type": "photo",
        "rawDate": "241107",
        "postNum": null,
        "originalId": "photo-241107"
    },
    {
        "id": "repost-67",
        "date": "2024-11-06",
        "displayDate": "2024년 11월 6일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241106.jpeg"
        ],
        "caption": "NOMAD is here 📞 24) 11-06",
        "type": "group",
        "rawDate": "241106",
        "postNum": null,
        "originalId": "group-241106"
    },
    {
        "id": "repost-68",
        "date": "2024-11-02",
        "displayDate": "2024년 11월 2일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241102.jpg"
        ],
        "caption": "NOMAD is here 📞 24) 11-01",
        "type": "group",
        "rawDate": "241102",
        "postNum": null,
        "originalId": "group-241102"
    },
    {
        "id": "repost-69",
        "date": "2024-11-01",
        "displayDate": "2024년 11월 1일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241101.jpg"
        ],
        "caption": "NOMAD is here 📞 24) 10-31",
        "type": "group",
        "rawDate": "241101",
        "postNum": null,
        "originalId": "group-241101"
    },
    {
        "id": "repost-70",
        "date": "2024-11-01",
        "displayDate": "2024년 11월 1일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241101%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241101%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241101%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241101%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241101%20(5).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241101%20(6).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241101%20(7).jpg"
        ],
        "caption": "KOREA BRAND EXPO📞",
        "type": "photo",
        "rawDate": "241101",
        "postNum": null,
        "originalId": "photo-241101"
    },
    {
        "id": "repost-71",
        "date": "2024-10-28",
        "displayDate": "2024년 10월 28일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241028%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241028%20(2).jpg"
        ],
        "caption": "Doky",
        "type": "photo",
        "rawDate": "241028",
        "postNum": null,
        "originalId": "photo-241028"
    },
    {
        "id": "repost-72",
        "date": "2024-10-25",
        "displayDate": "2024년 10월 25일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241025%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241025%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241025%20(3).jpg"
        ],
        "caption": "🐶🐶",
        "type": "photo",
        "rawDate": "241025",
        "postNum": null,
        "originalId": "photo-241025"
    },
    {
        "id": "repost-73",
        "date": "2024-10-24",
        "displayDate": "2024년 10월 24일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241024%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241024%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241024%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241024%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241024%20(5).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241024%20(6).mp4"
        ],
        "caption": "웃고 있는 노매드를 담았던 📷",
        "type": "group",
        "rawDate": "241024",
        "postNum": null,
        "originalId": "group-241024"
    },
    {
        "id": "repost-74",
        "date": "2024-10-19",
        "displayDate": "2024년 10월 19일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241019-2%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241019-2%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241019-2%20(3).jpg"
        ],
        "caption": "📞 Call Me Back with Music Bank",
        "type": "group",
        "rawDate": "241019",
        "postNum": 2,
        "originalId": "group-241019-2"
    },
    {
        "id": "repost-75",
        "date": "2024-10-19",
        "displayDate": "2024년 10월 19일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241019-1.jpg"
        ],
        "caption": "NOMAD is here 📞 24) 10-18",
        "type": "group",
        "rawDate": "241019",
        "postNum": 1,
        "originalId": "group-241019-1"
    },
    {
        "id": "repost-76",
        "date": "2024-10-18",
        "displayDate": "2024년 10월 18일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241018.jpg"
        ],
        "caption": "NOMAD is here 📞 24) 10-18",
        "type": "group",
        "rawDate": "241018",
        "postNum": null,
        "originalId": "group-241018"
    },
    {
        "id": "repost-77",
        "date": "2024-10-17",
        "displayDate": "2024년 10월 17일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241017%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241017%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241017%20(3).jpg"
        ],
        "caption": "📞 Call Me Back with Simply K-pop",
        "type": "group",
        "rawDate": "241017",
        "postNum": null,
        "originalId": "group-241017"
    },
    {
        "id": "repost-78",
        "date": "2024-10-15",
        "displayDate": "2024년 10월 15일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241015%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241015%20(2).jpg"
        ],
        "caption": "BGM : Call Me Back 💽",
        "type": "group",
        "rawDate": "241015",
        "postNum": null,
        "originalId": "group-241015"
    },
    {
        "id": "repost-79",
        "date": "2024-10-13",
        "displayDate": "2024년 10월 13일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241013-2%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241013-2%20(2).jpg"
        ],
        "caption": "캣잎 준호 🐈‍⬛<br>(원이는 촬영중🫣)",
        "type": "group",
        "rawDate": "241013",
        "postNum": 2,
        "originalId": "group-241013-2"
    },
    {
        "id": "repost-80",
        "date": "2024-10-13",
        "displayDate": "2024년 10월 13일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241013-1.jpg"
        ],
        "caption": "NOMAD is here 📞 24) 10-14",
        "type": "group",
        "rawDate": "241013",
        "postNum": 1,
        "originalId": "group-241013-1"
    },
    {
        "id": "repost-81",
        "date": "2024-10-12",
        "displayDate": "2024년 10월 12일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241012.jpg"
        ],
        "caption": "NOMAD is here 📞 24) 10-12",
        "type": "group",
        "rawDate": "241012",
        "postNum": null,
        "originalId": "group-241012"
    },
    {
        "id": "repost-82",
        "date": "2024-10-12",
        "displayDate": "2024년 10월 12일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241012%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241012%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/241012%20(3).jpg"
        ],
        "caption": "📼🎧🎵",
        "type": "photo",
        "rawDate": "241012",
        "postNum": null,
        "originalId": "photo-241012"
    },
    {
        "id": "repost-83",
        "date": "2024-10-11",
        "displayDate": "2024년 10월 11일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241011%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241011%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241011%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241011%20(4).jpg"
        ],
        "caption": "어항안에 갇힌 도의🐟<br>홍도의 아웃! 홍도의 아웃!",
        "type": "group",
        "rawDate": "241011",
        "postNum": null,
        "originalId": "group-241011"
    },
    {
        "id": "repost-84",
        "date": "2024-10-09",
        "displayDate": "2024년 10월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241009-2.jpg"
        ],
        "caption": "NOMAD is here 📞 24) 10-09",
        "type": "group",
        "rawDate": "241009",
        "postNum": 2,
        "originalId": "group-241009-2"
    },
    {
        "id": "repost-85",
        "date": "2024-10-09",
        "displayDate": "2024년 10월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241009-1.jpg"
        ],
        "caption": "Call Me Back 드디어 컴백 📞😊",
        "type": "group",
        "rawDate": "241009",
        "postNum": 1,
        "originalId": "group-241009-1"
    },
    {
        "id": "repost-86",
        "date": "2024-10-04",
        "displayDate": "2024년 10월 4일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/241004.jpg"
        ],
        "caption": "based on BASE 🖤",
        "type": "group",
        "rawDate": "241004",
        "postNum": null,
        "originalId": "group-241004"
    },
    {
        "id": "repost-87",
        "date": "2024-09-28",
        "displayDate": "2024년 9월 28일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240928%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240928%20(2).jpeg"
        ],
        "caption": "NOMAD 1st Single 【𝓒𝓪𝓵𝓵 𝓜𝓮 𝓑𝓪𝓬𝓴】<br><br>CONCEPT PHOTO #NOMAD<br><br>📞 2024.10.09 6PM (KST)",
        "type": "group",
        "rawDate": "240928",
        "postNum": null,
        "originalId": "group-240928"
    },
    {
        "id": "repost-88",
        "date": "2024-09-27",
        "displayDate": "2024년 9월 27일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240927%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240927%20(2).jpeg"
        ],
        "caption": "NOMAD 1st Single 【𝓒𝓪𝓵𝓵 𝓜𝓮 𝓑𝓪𝓬𝓴】<br><br>CONCEPT PHOTO #DOY<br><br>📞 2024.10.09 6PM (KST)",
        "type": "group",
        "rawDate": "240927",
        "postNum": null,
        "originalId": "group-240927"
    },
    {
        "id": "repost-89",
        "date": "2024-09-20",
        "displayDate": "2024년 9월 20일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240920.jpeg"
        ],
        "caption": "NOMAD 1st Single 【𝓒𝓪𝓵𝓵 𝓜𝓮 𝓑𝓪𝓬𝓴】<br><br>📞 2024.10.09 6PM (KST)",
        "type": "group",
        "rawDate": "240920",
        "postNum": null,
        "originalId": "group-240920"
    },
    {
        "id": "repost-90",
        "date": "2024-09-16",
        "displayDate": "2024년 9월 16일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240916.mp4"
        ],
        "caption": "Can you Call Me Back?",
        "type": "group",
        "rawDate": "240916",
        "postNum": null,
        "originalId": "group-240916"
    },
    {
        "id": "repost-91",
        "date": "2024-09-14",
        "displayDate": "2024년 9월 14일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240914.jpeg"
        ],
        "caption": "HAPPY 200 DAYS NOMAD!",
        "type": "group",
        "rawDate": "240914",
        "postNum": null,
        "originalId": "group-240914"
    },
    {
        "id": "repost-92",
        "date": "2024-08-31",
        "displayDate": "2024년 8월 31일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240831%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240831%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240831%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240831%20(4).jpg"
        ],
        "caption": "Good night🌙",
        "type": "photo",
        "rawDate": "240831",
        "postNum": null,
        "originalId": "photo-240831"
    },
    {
        "id": "repost-93",
        "date": "2024-08-23",
        "displayDate": "2024년 8월 23일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240823.jpg"
        ],
        "caption": "🥘 Made by ChefMAD",
        "type": "group",
        "rawDate": "240823",
        "postNum": null,
        "originalId": "group-240823"
    },
    {
        "id": "repost-94",
        "date": "2024-08-15",
        "displayDate": "2024년 8월 15일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240815.jpg"
        ],
        "caption": "NOMAD 2024 MZ FESTIVAL | 240815",
        "type": "group",
        "rawDate": "240815",
        "postNum": null,
        "originalId": "group-240815"
    },
    {
        "id": "repost-95",
        "date": "2024-07-07",
        "displayDate": "2024년 7월 7일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240707%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240707%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240707%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240707%20(4).jpg"
        ],
        "caption": "주말인데 다들 뭐했어?",
        "type": "photo",
        "rawDate": "240707",
        "postNum": null,
        "originalId": "photo-240707"
    },
    {
        "id": "repost-96",
        "date": "2024-06-21",
        "displayDate": "2024년 6월 21일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240621%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240621%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240621%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240621%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240621%20(5).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240621%20(6).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240621%20(7).jpg"
        ],
        "caption": "Nos vemos",
        "type": "photo",
        "rawDate": "240621",
        "postNum": null,
        "originalId": "photo-240621"
    },
    {
        "id": "repost-97",
        "date": "2024-06-20",
        "displayDate": "2024년 6월 20일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240620%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240620%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240620%20(3).jpg"
        ],
        "caption": "recuerdos de Mexico 📷",
        "type": "group",
        "rawDate": "240620",
        "postNum": null,
        "originalId": "group-240620"
    },
    {
        "id": "repost-98",
        "date": "2024-06-17",
        "displayDate": "2024년 6월 17일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240617%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240617%20(2).jpeg"
        ],
        "caption": "NOMAD 2024 K-BRAND EXPO IN MEXICO<br>Muchas gracias BASE Mexicana!",
        "type": "group",
        "rawDate": "240617",
        "postNum": null,
        "originalId": "group-240617"
    },
    {
        "id": "repost-99",
        "date": "2024-06-06",
        "displayDate": "2024년 6월 6일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240606.jpeg"
        ],
        "caption": "HAPPY 100 DAYS NOMAD!",
        "type": "group",
        "rawDate": "240606",
        "postNum": null,
        "originalId": "group-240606"
    },
    {
        "id": "repost-100",
        "date": "2024-05-28",
        "displayDate": "2024년 5월 28일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240528.jpg"
        ],
        "caption": "☁️ 한 점 없는",
        "type": "photo",
        "rawDate": "240528",
        "postNum": null,
        "originalId": "photo-240528"
    },
    {
        "id": "repost-101",
        "date": "2024-05-22",
        "displayDate": "2024년 5월 22일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240522%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240522%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240522%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240522%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240522%20(5).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240522%20(6).jpg"
        ],
        "caption": "☀️",
        "type": "photo",
        "rawDate": "240522",
        "postNum": null,
        "originalId": "photo-240522"
    },
    {
        "id": "repost-102",
        "date": "2024-05-16",
        "displayDate": "2024년 5월 16일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240516%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240516%20(2).jpeg"
        ],
        "caption": "NOMAD KMPF 2024 | 240516",
        "type": "group",
        "rawDate": "240516",
        "postNum": null,
        "originalId": "group-240516"
    },
    {
        "id": "repost-103",
        "date": "2024-05-14",
        "displayDate": "2024년 5월 14일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240514%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240514%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240514%20(3).jpg"
        ],
        "caption": "trapped",
        "type": "photo",
        "rawDate": "240514",
        "postNum": null,
        "originalId": "photo-240514"
    },
    {
        "id": "repost-104",
        "date": "2024-05-07",
        "displayDate": "2024년 5월 7일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240507%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240507%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240507%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240507%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240507%20(5).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240507%20(6).jpg"
        ],
        "caption": "오사카의 밤",
        "type": "photo",
        "rawDate": "240507",
        "postNum": null,
        "originalId": "photo-240507"
    },
    {
        "id": "repost-105",
        "date": "2024-05-04",
        "displayDate": "2024년 5월 4일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240504%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240504%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240504%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240504%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240504%20(5).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240504%20(6).jpg"
        ],
        "caption": "📸",
        "type": "group",
        "rawDate": "240504",
        "postNum": null,
        "originalId": "group-240504"
    },
    {
        "id": "repost-106",
        "date": "2024-05-04",
        "displayDate": "2024년 5월 4일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240504%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240504%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240504%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240504%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240504%20(5).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240504%20(6).jpg"
        ],
        "caption": "Osaka street",
        "type": "photo",
        "rawDate": "240504",
        "postNum": null,
        "originalId": "photo-240504"
    },
    {
        "id": "repost-107",
        "date": "2024-04-29",
        "displayDate": "2024년 4월 29일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240429%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240429%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240429%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240429%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240429%20(5).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240429%20(6).jpg"
        ],
        "caption": "JAPAN SHOWCASE Behind the stage",
        "type": "group",
        "rawDate": "240429",
        "postNum": null,
        "originalId": "group-240429"
    },
    {
        "id": "repost-108",
        "date": "2024-04-26",
        "displayDate": "2024년 4월 26일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240426%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240426%20(2).jpeg"
        ],
        "caption": "NOMAD 2024 SHOWCASE IN JAPAN",
        "type": "group",
        "rawDate": "240426",
        "postNum": null,
        "originalId": "group-240426"
    },
    {
        "id": "repost-109",
        "date": "2024-04-17",
        "displayDate": "2024년 4월 17일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240417.jpg"
        ],
        "caption": "Casper",
        "type": "photo",
        "rawDate": "240417",
        "postNum": null,
        "originalId": "photo-240417"
    },
    {
        "id": "repost-110",
        "date": "2024-04-12",
        "displayDate": "2024년 4월 12일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240412.jpg"
        ],
        "caption": "#DOY_was_here 👣",
        "type": "photo",
        "rawDate": "240412",
        "postNum": null,
        "originalId": "photo-240412"
    },
    {
        "id": "repost-111",
        "date": "2024-03-28",
        "displayDate": "2024년 3월 28일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240328%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240328%20(2).jpeg"
        ],
        "caption": "NOMAD SHOW CHAMPION | 240327✨",
        "type": "group",
        "rawDate": "240328",
        "postNum": null,
        "originalId": "group-240328"
    },
    {
        "id": "repost-112",
        "date": "2024-03-21",
        "displayDate": "2024년 3월 21일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240321%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240321%20(2).jpeg"
        ],
        "caption": "NOMAD SHOW CHAMPION | 240320",
        "type": "group",
        "rawDate": "240321",
        "postNum": null,
        "originalId": "group-240321"
    },
    {
        "id": "repost-113",
        "date": "2024-03-19",
        "displayDate": "2024년 3월 19일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240319%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240319%20(2).jpeg"
        ],
        "caption": "NOMAD THE SHOW | 240319 🌟",
        "type": "group",
        "rawDate": "240319",
        "postNum": null,
        "originalId": "group-240319"
    },
    {
        "id": "repost-114",
        "date": "2024-03-17",
        "displayDate": "2024년 3월 17일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240317%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240317%20(2).jpeg"
        ],
        "caption": "NOMAD INKIGAYO | 240317 🎸",
        "type": "group",
        "rawDate": "240317",
        "postNum": null,
        "originalId": "group-240317"
    },
    {
        "id": "repost-115",
        "date": "2024-03-16",
        "displayDate": "2024년 3월 16일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240316.jpeg"
        ],
        "caption": "NOMAD SHOW! MUSIC CORE | 240316 🎼",
        "type": "group",
        "rawDate": "240316",
        "postNum": null,
        "originalId": "group-240316"
    },
    {
        "id": "repost-116",
        "date": "2024-03-15",
        "displayDate": "2024년 3월 15일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240315%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240315%20(2).jpeg"
        ],
        "caption": "NOMAD Music Bank | 240315 🎧",
        "type": "group",
        "rawDate": "240315",
        "postNum": null,
        "originalId": "group-240315"
    },
    {
        "id": "repost-117",
        "date": "2024-03-14",
        "displayDate": "2024년 3월 14일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240314%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240314%20(2).jpeg"
        ],
        "caption": "NOMAD SHOW CHAMPION | 240313 🎶",
        "type": "group",
        "rawDate": "240314",
        "postNum": null,
        "originalId": "group-240314"
    },
    {
        "id": "repost-118",
        "date": "2024-03-12",
        "displayDate": "2024년 3월 12일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240312-2%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240312-2%20(2).jpeg"
        ],
        "caption": "NOMAD THE SHOW | 240312 ✨",
        "type": "group",
        "rawDate": "240312",
        "postNum": 2,
        "originalId": "group-240312-2"
    },
    {
        "id": "repost-119",
        "date": "2024-03-12",
        "displayDate": "2024년 3월 12일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240312-1%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240312-1%20(2).jpeg"
        ],
        "caption": "NOMAD 노매드 1st EP <NOMAD><br>Cali ver<br>CONCEPT PHOTO 2<br><br>2024.03.13 WED 6PM (KST)<br>'California love' MV RELEASE",
        "type": "group",
        "rawDate": "240312",
        "postNum": 1,
        "originalId": "group-240312-1"
    },
    {
        "id": "repost-120",
        "date": "2024-03-11",
        "displayDate": "2024년 3월 11일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240311%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240311%20(2).jpeg"
        ],
        "caption": "NOMAD 노매드 1st EP <NOMAD><br>Cali ver<br>CONCEPT PHOTO 1<br><br>2024.03.13 WED 6PM (KST)<br>'California love' MV RELEASE",
        "type": "group",
        "rawDate": "240311",
        "postNum": null,
        "originalId": "group-240311"
    },
    {
        "id": "repost-121",
        "date": "2024-03-09",
        "displayDate": "2024년 3월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240309-2%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240309-2%20(2).jpeg"
        ],
        "caption": "3/9 쇼!음악중심",
        "type": "group",
        "rawDate": "240309",
        "postNum": 2,
        "originalId": "group-240309-2"
    },
    {
        "id": "repost-122",
        "date": "2024-03-09",
        "displayDate": "2024년 3월 9일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240309-1.jpeg"
        ],
        "caption": "Swimmin' to you",
        "type": "group",
        "rawDate": "240309",
        "postNum": 1,
        "originalId": "group-240309-1"
    },
    {
        "id": "repost-123",
        "date": "2024-03-08",
        "displayDate": "2024년 3월 8일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240308%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240308%20(2).jpeg"
        ],
        "caption": "3/8 뮤직뱅크 💰",
        "type": "group",
        "rawDate": "240308",
        "postNum": null,
        "originalId": "group-240308"
    },
    {
        "id": "repost-124",
        "date": "2024-03-07",
        "displayDate": "2024년 3월 7일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240307%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240307%20(2).jpeg"
        ],
        "caption": "3/7 Mnet 두 번째 엠카운트다운💎",
        "type": "group",
        "rawDate": "240307",
        "postNum": null,
        "originalId": "group-240307"
    },
    {
        "id": "repost-125",
        "date": "2024-03-05",
        "displayDate": "2024년 3월 5일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240305-2%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240305-2%20(2).jpeg"
        ],
        "caption": "3/5 더쇼 Ⓜ️",
        "type": "group",
        "rawDate": "240305",
        "postNum": 2,
        "originalId": "group-240305-2"
    },
    {
        "id": "repost-126",
        "date": "2024-03-05",
        "displayDate": "2024년 3월 5일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240305-1%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240305-1%20(2).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240305-1%20(3).jpeg"
        ],
        "caption": "NOMAD Simply K-Pop | 240304 ⏯️",
        "type": "group",
        "rawDate": "240305",
        "postNum": 1,
        "originalId": "group-240305-1"
    },
    {
        "id": "repost-127",
        "date": "2024-03-03",
        "displayDate": "2024년 3월 3일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240303%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240303%20(2).jpeg"
        ],
        "caption": "NOMAD INKIGAYO | 240303 📸",
        "type": "group",
        "rawDate": "240303",
        "postNum": null,
        "originalId": "group-240303"
    },
    {
        "id": "repost-128",
        "date": "2024-03-02",
        "displayDate": "2024년 3월 2일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240302-2%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240302-2%20(2).jpeg"
        ],
        "caption": "NOMAD SHOW! MUSIC CORE | 240302 🎤",
        "type": "group",
        "rawDate": "240302",
        "postNum": 2,
        "originalId": "group-240302-2"
    },
    {
        "id": "repost-129",
        "date": "2024-03-02",
        "displayDate": "2024년 3월 2일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240302-1%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240302-1%20(2).jpeg"
        ],
        "caption": "NOMAD Music Bank | 240301 📷",
        "type": "group",
        "rawDate": "240302",
        "postNum": 1,
        "originalId": "group-240302-1"
    },
    {
        "id": "repost-130",
        "date": "2024-03-01",
        "displayDate": "2024년 3월 1일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240301.jpeg"
        ],
        "caption": "NOMAD Mcountdown | 240229✨",
        "type": "group",
        "rawDate": "240301",
        "postNum": null,
        "originalId": "group-240301"
    },
    {
        "id": "repost-131",
        "date": "2024-02-29",
        "displayDate": "2024년 2월 29일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240229%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240229%20(2).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240229%20(3).jpeg"
        ],
        "caption": "BASE 여러분,<br>NOMAD의 여정이 이제 시작되었습니다.<br>첫 발걸음을 함께해 주신 BASE 여러분께 깊은 감사를 드립니다.<br><br>‘BASE’라는 소중한 팬네임은<br>다섯 멤버들의 아이디어에서 시작되었습니다.<br><br>NOMAD의 ‘Basecamp’로써, 다섯 명의 NOMAD가 향하는 방향을 알려주기도 하고<br>다섯 명의 NOMAD가 향하는 목표를 함께 오르는 존재가 되어주시길 바라는 마음을 담아 탄생한 이름입니다.<br><br>또한 NOMAD의 근간이 되는 존재로서,<br>또 다른 ‘NOMAD’의 여섯 번째 멤버로서 앞으로도 계속 이 여정에 함께해 주시길 바랍니다.<br>감사합니다.<br><br>NOMAD & NOMAD Entertainment 드림",
        "type": "group",
        "rawDate": "240229",
        "postNum": null,
        "originalId": "group-240229"
    },
    {
        "id": "repost-132",
        "date": "2024-02-13",
        "displayDate": "2024년 2월 13일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240213%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240213%20(2).jpeg"
        ],
        "caption": "노매드 1st EP <NOMAD><br>CONCEPT PHOTO 2 #DOY<br><br>2024.02.28 WED 6PM (KST)<br>1st EP <NOMAD> RELEASE",
        "type": "group",
        "rawDate": "240213",
        "postNum": null,
        "originalId": "group-240213"
    },
    {
        "id": "repost-133",
        "date": "2024-02-12",
        "displayDate": "2024년 2월 12일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240212%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240212%20(2).jpeg"
        ],
        "caption": "NOMAD 노매드 1st EP <NOMAD><br>CONCEPT PHOTO 1<br><br>2024.02.28 WED 6PM (KST)<br>1st EP <NOMAD> RELEASE",
        "type": "group",
        "rawDate": "240212",
        "postNum": null,
        "originalId": "group-240212"
    },
    {
        "id": "repost-134",
        "date": "2024-02-10",
        "displayDate": "2024년 2월 10일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240210%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240210%20(2).jpeg"
        ],
        "caption": "NOMAD 노매드<br>MOOD IMAGE 1 #DOY",
        "type": "group",
        "rawDate": "240210",
        "postNum": null,
        "originalId": "group-240210"
    },
    {
        "id": "repost-135",
        "date": "2024-02-08",
        "displayDate": "2024년 2월 8일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240208.jpeg"
        ],
        "caption": "NOMAD 노매드<br>DEBUT CONCEPT POSTER #NOMAD",
        "type": "group",
        "rawDate": "240208",
        "postNum": null,
        "originalId": "group-240208"
    },
    {
        "id": "repost-136",
        "date": "2024-02-06",
        "displayDate": "2024년 2월 6일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240206-3.jpeg"
        ],
        "caption": "NOMAD 노매드<br>TEASER IMAGE #2<br><br>2024.02.28<br>1ST EP \"NOMAD\" RELEASE",
        "type": "group",
        "rawDate": "240206",
        "postNum": 3,
        "originalId": "group-240206-3"
    },
    {
        "id": "repost-137",
        "date": "2024-02-06",
        "displayDate": "2024년 2월 6일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240206-2.jpeg"
        ],
        "caption": "NOMAD 노매드<br>TEASER IMAGE #2<br><br>2024.02.28<br>1ST EP \"NOMAD\" RELEASE",
        "type": "group",
        "rawDate": "240206",
        "postNum": 2,
        "originalId": "group-240206-2"
    },
    {
        "id": "repost-138",
        "date": "2024-02-06",
        "displayDate": "2024년 2월 6일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240206-1.jpeg"
        ],
        "caption": "NOMAD 노매드<br>TEASER IMAGE #2<br><br>2024.02.28<br>1ST EP \"NOMAD\" RELEASE",
        "type": "group",
        "rawDate": "240206",
        "postNum": 1,
        "originalId": "group-240206-1"
    },
    {
        "id": "repost-139",
        "date": "2024-02-05",
        "displayDate": "2024년 2월 5일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240205-3.jpeg"
        ],
        "caption": "NOMAD 노매드<br>TEASER IMAGE #1<br><br>2024.02.28<br>1ST EP \"NOMAD\" RELEASE",
        "type": "group",
        "rawDate": "240205",
        "postNum": 3,
        "originalId": "group-240205-3"
    },
    {
        "id": "repost-140",
        "date": "2024-02-05",
        "displayDate": "2024년 2월 5일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240205-2.jpeg"
        ],
        "caption": "NOMAD 노매드<br>TEASER IMAGE #1<br><br>2024.02.28<br>1ST EP \"NOMAD\" RELEASE",
        "type": "group",
        "rawDate": "240205",
        "postNum": 2,
        "originalId": "group-240205-2"
    },
    {
        "id": "repost-141",
        "date": "2024-02-05",
        "displayDate": "2024년 2월 5일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240205-1.jpeg"
        ],
        "caption": "NOMAD 노매드<br>TEASER IMAGE #1<br><br>2024.02.28<br>1ST EP \"NOMAD\" RELEASE",
        "type": "group",
        "rawDate": "240205",
        "postNum": 1,
        "originalId": "group-240205-1"
    },
    {
        "id": "repost-142",
        "date": "2024-01-19",
        "displayDate": "2024년 1월 19일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240119%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240119%20(2).jpg"
        ],
        "caption": "🎬",
        "type": "group",
        "rawDate": "240119",
        "postNum": null,
        "originalId": "group-240119"
    },
    {
        "id": "repost-143",
        "date": "2024-01-18",
        "displayDate": "2024년 1월 18일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240118-2.jpg"
        ],
        "caption": "Runnnnn",
        "type": "group",
        "rawDate": "240118",
        "postNum": 2,
        "originalId": "group-240118-2"
    },
    {
        "id": "repost-144",
        "date": "2024-01-18",
        "displayDate": "2024년 1월 18일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240118-1.jpg"
        ],
        "caption": "Night walk",
        "type": "group",
        "rawDate": "240118",
        "postNum": 1,
        "originalId": "group-240118-1"
    },
    {
        "id": "repost-145",
        "date": "2024-01-11",
        "displayDate": "2024년 1월 11일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240111-2.jpg"
        ],
        "caption": "💭",
        "type": "photo",
        "rawDate": "240111",
        "postNum": 2,
        "originalId": "photo-240111-2"
    },
    {
        "id": "repost-146",
        "date": "2024-01-11",
        "displayDate": "2024년 1월 11일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240111%20(1).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240111%20(2).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240111%20(3).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240111%20(4).jpg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-photo/240111%20(5).jpg"
        ],
        "caption": "",
        "type": "photo",
        "rawDate": "240111",
        "postNum": null,
        "originalId": "photo-240111"
    },
    {
        "id": "repost-147",
        "date": "2024-01-01",
        "displayDate": "2024년 1월 1일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240101%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240101%20(2).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240101%20(3).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/240101%20(4).jpeg"
        ],
        "caption": "📷 Behind cut #도의<br>Watch the 'Lights on' Performance Video on ▶ Youtube",
        "type": "group",
        "rawDate": "240101",
        "postNum": null,
        "originalId": "group-240101"
    },
    {
        "id": "repost-148",
        "date": "2023-12-30",
        "displayDate": "2023년 12월 30일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/231230%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/231230%20(2).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/231230%20(3).jpeg"
        ],
        "caption": "📷 Behind cut #노매드<br>Watch the 'Lights on' Performance Video on ▶ Youtube",
        "type": "group",
        "rawDate": "231230",
        "postNum": null,
        "originalId": "group-231230"
    },
    {
        "id": "repost-149",
        "date": "2023-12-28",
        "displayDate": "2023년 12월 28일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/231228%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/231228%20(2).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/231228%20(3).jpeg"
        ],
        "caption": "📷 Behind cut #도의<br>Watch the 'Lights on' Performance Video on ▶ Youtube",
        "type": "group",
        "rawDate": "231228",
        "postNum": null,
        "originalId": "group-231228"
    },
    {
        "id": "repost-150",
        "date": "2023-12-22",
        "displayDate": "2023년 12월 22일",
        "username": "doy.is.here",
        "images": [
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/231222%20(1).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/231222%20(2).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/231222%20(3).jpeg",
            "https://raw.githubusercontent.com/DOY-is-here/doy-is-here.github.io/main/insta-group/231222%20(4).jpeg"
        ],
        "caption": "도의 (DOY)<br><br>2023.12.27 NOMAD 1st ep B-side Track 'Lights On'<br>Performance Video Pre-release",
        "type": "group",
        "rawDate": "231222",
        "postNum": null,
        "originalId": "group-231222"
    }
];

// 탭별 게시물 가져오기
export function getPostsByTab(tab) {
    switch(tab) {
        case 'grid':
            return photoPosts;
        case 'tagged':
            return groupPosts;
        case 'story':
            return storyPosts;
        case 'repost':
            return repostPosts;
        default:
            return photoPosts;
    }
}

// 게시물 개수
export function getPostCount(tab = 'grid') {
    return getPostsByTab(tab).length;
}

// ID로 게시물 찾기
export function getPostById(id) {
    const allPosts = [...photoPosts, ...groupPosts, ...storyPosts, ...repostPosts];
    return allPosts.find(post => post.id === id);
}

// 다음 게시물
export function getNextPost(currentId, tab = 'grid') {
    const posts = getPostsByTab(tab);
    const currentIndex = posts.findIndex(post => post.id === currentId);
    if (currentIndex === -1 || currentIndex === posts.length - 1) return null;
    return posts[currentIndex + 1];
}

// 이전 게시물
export function getPrevPost(currentId, tab = 'grid') {
    const posts = getPostsByTab(tab);
    const currentIndex = posts.findIndex(post => post.id === currentId);
    if (currentIndex <= 0) return null;
    return posts[currentIndex - 1];
}

// 추가 호환성 함수들
export function getPhotos() {
    return photoPosts;
}

export function getReels() {
    return []; // 릴스가 없으면 빈 배열 반환
}

export function getTaggedPosts() {
    return groupPosts;
}

export function getStories() {
    return storyPosts;
}

// posts 변수 (기존 코드와의 호환성)
export const posts = photoPosts;
